"""SQLite persistence layer for the ASM tool.

Kept intentionally small: three tables (targets, assets, scans) and a handful
of helpers. The interesting bit is `upsert_asset`, which decides whether a
discovered asset is *new* (never seen before) and flags it accordingly.
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

DB_PATH = os.environ.get("ASM_DB_PATH", os.path.join("data", "asm.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS groups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    color       TEXT,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS targets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT,
    value           TEXT UNIQUE NOT NULL,      -- domain or IP you onboard
    enabled         INTEGER NOT NULL DEFAULT 1,
    added_at        TEXT NOT NULL,
    last_scan_at    TEXT,
    last_status     TEXT DEFAULT 'pending',    -- pending | scanning | ok | error
    enumerate_subs  INTEGER NOT NULL DEFAULT 1,-- run subdomain discovery on scan
    parent_id       INTEGER,                   -- set when auto-added from a parent
    source          TEXT NOT NULL DEFAULT 'manual',  -- manual | subdomain
    scan_mode       TEXT NOT NULL DEFAULT 'passive', -- passive | light | aggressive
    group_id        INTEGER                    -- folder / group membership
);

CREATE TABLE IF NOT EXISTS assets (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id     INTEGER NOT NULL,
    kind          TEXT NOT NULL,             -- host | port | tech | endpoint
    akey          TEXT NOT NULL,             -- stable identity for de-dup
    label         TEXT NOT NULL,             -- human-readable summary
    details       TEXT,                      -- JSON blob
    first_seen    TEXT NOT NULL,
    last_seen     TEXT NOT NULL,
    is_new        INTEGER NOT NULL DEFAULT 1,
    acknowledged  INTEGER NOT NULL DEFAULT 0,
    status        TEXT NOT NULL DEFAULT 'active',   -- active | gone
    UNIQUE(target_id, kind, akey),
    FOREIGN KEY(target_id) REFERENCES targets(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scans (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id   INTEGER NOT NULL,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    status      TEXT NOT NULL DEFAULT 'running',
    new_count   INTEGER DEFAULT 0,
    gone_count  INTEGER DEFAULT 0,
    summary     TEXT,
    FOREIGN KEY(target_id) REFERENCES targets(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_assets_target ON assets(target_id);
CREATE INDEX IF NOT EXISTS idx_assets_new ON assets(is_new);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def init_db() -> None:
    conn = connect()
    with conn:
        conn.executescript(SCHEMA)
        _migrate(conn)
    conn.close()


def _migrate(conn: sqlite3.Connection) -> None:
    """Additive migrations so existing databases pick up new columns."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(targets)")}
    additions = {
        "enumerate_subs": "INTEGER NOT NULL DEFAULT 1",
        "parent_id": "INTEGER",
        "source": "TEXT NOT NULL DEFAULT 'manual'",
        "scan_mode": "TEXT NOT NULL DEFAULT 'passive'",
        "group_id": "INTEGER",
    }
    for col, ddl in additions.items():
        if col not in cols:
            conn.execute(f"ALTER TABLE targets ADD COLUMN {col} {ddl}")


def row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    if "details" in d and d["details"]:
        try:
            d["details"] = json.loads(d["details"])
        except (json.JSONDecodeError, TypeError):
            pass
    return d


# ---------------------------------------------------------------- targets ---

def add_target(conn: sqlite3.Connection, value: str, name: str | None = None,
               enumerate_subs: bool = True, parent_id: int | None = None,
               source: str = "manual", scan_mode: str = "passive",
               group_id: int | None = None) -> dict:
    value = value.strip().lower()
    with conn:
        conn.execute(
            "INSERT OR IGNORE INTO targets(name, value, added_at, enumerate_subs, "
            "parent_id, source, scan_mode, group_id) VALUES(?,?,?,?,?,?,?,?)",
            (name or value, value, now(), 1 if enumerate_subs else 0, parent_id,
             source, scan_mode, group_id),
        )
    row = conn.execute("SELECT * FROM targets WHERE value=?", (value,)).fetchone()
    return row_to_dict(row)


def get_target_by_value(conn: sqlite3.Connection, value: str) -> dict | None:
    row = conn.execute("SELECT * FROM targets WHERE value=?",
                       (value.strip().lower(),)).fetchone()
    return row_to_dict(row) if row else None


# ------------------------------------------------------------------ groups ---

GROUP_COLORS = ["#3dd6b6", "#6db3ff", "#b58cff", "#ff9e6d", "#f5d76e",
                "#ff6b6b", "#7bd88f", "#c99bff", "#5fb0d4", "#ffb4a2"]


def add_group(conn: sqlite3.Connection, name: str, color: str | None = None) -> dict:
    name = name.strip()
    if not color:
        n = conn.execute("SELECT COUNT(*) FROM groups").fetchone()[0]
        color = GROUP_COLORS[n % len(GROUP_COLORS)]
    with conn:
        conn.execute("INSERT OR IGNORE INTO groups(name, color, created_at) VALUES(?,?,?)",
                     (name, color, now()))
    row = conn.execute("SELECT * FROM groups WHERE name=?", (name,)).fetchone()
    return row_to_dict(row)


def list_groups(conn: sqlite3.Connection) -> list[dict]:
    groups = [row_to_dict(r) for r in
              conn.execute("SELECT * FROM groups ORDER BY name")]
    # attach target + new-finding counts per group
    for g in groups:
        g["targets"] = conn.execute(
            "SELECT COUNT(*) FROM targets WHERE group_id=?", (g["id"],)).fetchone()[0]
        g["new"] = conn.execute(
            "SELECT COUNT(*) FROM assets a JOIN targets t ON t.id=a.target_id "
            "WHERE t.group_id=? AND a.is_new=1 AND a.acknowledged=0", (g["id"],)).fetchone()[0]
    return groups


def rename_group(conn: sqlite3.Connection, group_id: int, name: str | None = None,
                 color: str | None = None) -> None:
    with conn:
        if name is not None:
            conn.execute("UPDATE groups SET name=? WHERE id=?", (name.strip(), group_id))
        if color is not None:
            conn.execute("UPDATE groups SET color=? WHERE id=?", (color, group_id))


def delete_group(conn: sqlite3.Connection, group_id: int) -> None:
    """Delete a group; its targets become ungrouped (targets are NOT removed)."""
    with conn:
        conn.execute("UPDATE targets SET group_id=NULL WHERE group_id=?", (group_id,))
        conn.execute("DELETE FROM groups WHERE id=?", (group_id,))


def set_target_group(conn: sqlite3.Connection, target_id: int,
                     group_id: int | None) -> None:
    """Assign a target (and any subdomains beneath it) to a group."""
    with conn:
        conn.execute("UPDATE targets SET group_id=? WHERE id=? OR parent_id=?",
                     (group_id, target_id, target_id))


def list_targets(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM targets ORDER BY added_at DESC").fetchall()
    return [row_to_dict(r) for r in rows]


def get_target(conn: sqlite3.Connection, target_id: int) -> dict | None:
    row = conn.execute("SELECT * FROM targets WHERE id=?", (target_id,)).fetchone()
    return row_to_dict(row) if row else None


def delete_target(conn: sqlite3.Connection, target_id: int) -> None:
    with conn:
        conn.execute("DELETE FROM targets WHERE id=?", (target_id,))


def set_target_status(conn: sqlite3.Connection, target_id: int, status: str,
                      scanned: bool = False) -> None:
    with conn:
        if scanned:
            conn.execute(
                "UPDATE targets SET last_status=?, last_scan_at=? WHERE id=?",
                (status, now(), target_id),
            )
        else:
            conn.execute(
                "UPDATE targets SET last_status=? WHERE id=?", (status, target_id)
            )


# ----------------------------------------------------------------- assets ---

def upsert_asset(conn: sqlite3.Connection, target_id: int, kind: str, akey: str,
                 label: str, details: dict) -> bool:
    """Insert or refresh an asset. Returns True if this was a *newly* seen asset."""
    ts = now()
    existing = conn.execute(
        "SELECT id FROM assets WHERE target_id=? AND kind=? AND akey=?",
        (target_id, kind, akey),
    ).fetchone()
    with conn:
        if existing:
            conn.execute(
                "UPDATE assets SET last_seen=?, label=?, details=?, status='active' "
                "WHERE id=?",
                (ts, label, json.dumps(details), existing["id"]),
            )
            return False
        conn.execute(
            "INSERT INTO assets(target_id, kind, akey, label, details, first_seen, "
            "last_seen, is_new, status) VALUES(?,?,?,?,?,?,?,1,'active')",
            (target_id, kind, akey, label, json.dumps(details), ts, ts),
        )
        return True


def mark_stale_gone(conn: sqlite3.Connection, target_id: int, scan_start: str) -> int:
    """Anything not touched since the scan started is no longer present."""
    with conn:
        cur = conn.execute(
            "UPDATE assets SET status='gone' WHERE target_id=? AND status='active' "
            "AND last_seen < ?",
            (target_id, scan_start),
        )
        return cur.rowcount


def list_assets(conn: sqlite3.Connection, target_id: int | None = None,
                kind: str | None = None, new_only: bool = False,
                family: bool = False, q: str | None = None,
                new_hours: int | None = None, group_id: int | None = None) -> list[dict]:
    sql = "SELECT a.*, t.value AS target_value FROM assets a JOIN targets t ON t.id=a.target_id WHERE 1=1"
    args: list[Any] = []
    if group_id is not None:
        sql += " AND t.group_id=?"
        args.append(group_id)
    if target_id is not None:
        if family:
            kids = [r["id"] for r in conn.execute(
                "SELECT id FROM targets WHERE parent_id=?", (target_id,))]
            ids = [target_id, *kids]
            sql += " AND a.target_id IN (%s)" % ",".join("?" * len(ids))
            args.extend(ids)
        else:
            sql += " AND a.target_id=?"
            args.append(target_id)
    if kind:
        sql += " AND a.kind=?"
        args.append(kind)
    if new_only:
        sql += " AND a.is_new=1 AND a.acknowledged=0"
    if new_hours:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=new_hours)).isoformat(timespec="seconds")
        sql += " AND a.first_seen >= ?"
        args.append(cutoff)
    if q:
        like = f"%{q.strip()}%"
        sql += " AND (a.label LIKE ? OR t.value LIKE ? OR a.kind LIKE ? OR a.details LIKE ?)"
        args.extend([like, like, like, like])
    sql += " ORDER BY t.value, a.is_new DESC, a.last_seen DESC"
    rows = conn.execute(sql, args).fetchall()
    return [row_to_dict(r) for r in rows]


def acknowledge_asset(conn: sqlite3.Connection, asset_id: int) -> None:
    with conn:
        conn.execute(
            "UPDATE assets SET acknowledged=1, is_new=0 WHERE id=?", (asset_id,)
        )


def acknowledge_all(conn: sqlite3.Connection, target_id: int | None = None) -> int:
    q = "UPDATE assets SET acknowledged=1, is_new=0 WHERE is_new=1"
    args: list[Any] = []
    if target_id is not None:
        q += " AND target_id=?"
        args.append(target_id)
    with conn:
        cur = conn.execute(q, args)
        return cur.rowcount


# ------------------------------------------------------------------ scans ---

def start_scan(conn: sqlite3.Connection, target_id: int) -> int:
    with conn:
        cur = conn.execute(
            "INSERT INTO scans(target_id, started_at) VALUES(?,?)",
            (target_id, now()),
        )
        return cur.lastrowid


def finish_scan(conn: sqlite3.Connection, scan_id: int, status: str,
                new_count: int, gone_count: int, summary: str) -> None:
    with conn:
        conn.execute(
            "UPDATE scans SET finished_at=?, status=?, new_count=?, gone_count=?, "
            "summary=? WHERE id=?",
            (now(), status, new_count, gone_count, summary, scan_id),
        )


def prune(conn: sqlite3.Connection, days: int) -> dict:
    """Apply data retention. Deletes scan-history rows older than `days`, and
    assets that have been *gone* longer than `days`. Never removes active
    assets (your current surface), whatever their age. days<=0 disables it.
    """
    if not days or days <= 0:
        return {"scans": 0, "assets": 0, "cutoff": None}
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="seconds")
    with conn:
        s = conn.execute("DELETE FROM scans WHERE started_at < ?", (cutoff,)).rowcount
        a = conn.execute("DELETE FROM assets WHERE status='gone' AND last_seen < ?",
                         (cutoff,)).rowcount
    return {"scans": s, "assets": a, "cutoff": cutoff}


def recent_scans(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        "SELECT s.*, t.value AS target_value FROM scans s "
        "JOIN targets t ON t.id=s.target_id ORDER BY s.started_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    return [row_to_dict(r) for r in rows]


def stats(conn: sqlite3.Connection) -> dict:
    def scalar(q: str) -> int:
        return conn.execute(q).fetchone()[0]

    return {
        "targets": scalar("SELECT COUNT(*) FROM targets"),
        "assets": scalar("SELECT COUNT(*) FROM assets WHERE status='active'"),
        "new": scalar("SELECT COUNT(*) FROM assets WHERE is_new=1 AND acknowledged=0"),
        "ports": scalar("SELECT COUNT(*) FROM assets WHERE kind='port' AND status='active'"),
        "techs": scalar("SELECT COUNT(*) FROM assets WHERE kind='tech' AND status='active'"),
        "endpoints": scalar("SELECT COUNT(*) FROM assets WHERE kind='endpoint' AND status='active'"),
        "subdomains": scalar("SELECT COUNT(*) FROM assets WHERE kind='subdomain' AND status='active'"),
        "waf": scalar("SELECT COUNT(*) FROM assets WHERE kind='waf' AND status='active'"),
        "buckets": scalar("SELECT COUNT(*) FROM assets WHERE kind='bucket' AND status='active'"),
        "public_buckets": scalar(
            "SELECT COUNT(*) FROM assets WHERE kind='bucket' AND status='active' "
            "AND details LIKE '%\"public\": true%'"),
        "breaches": scalar("SELECT COUNT(*) FROM assets WHERE kind='breach' AND status='active'"),
        "vulns": scalar("SELECT COUNT(*) FROM assets WHERE kind='vuln' AND status='active'"),
    }


def graph(conn: sqlite3.Connection, target_ids: list[int] | None = None,
          group_id: int | None = None) -> dict:
    """Build a node/link mesh of targets and their assets.

    target_ids selects which domains to include (their subdomains are pulled in
    automatically); group_id restricts to a folder; None means every target. IP
    nodes are global (deduped), so subdomains sharing infrastructure connect.
    """
    targets = list_targets(conn)
    tmap = {t["id"]: t for t in targets}
    if group_id is not None:
        scope = {t["id"] for t in targets if t["group_id"] == group_id}
    elif target_ids:
        chosen = set(target_ids)
        scope = set(chosen) | {t["id"] for t in targets if t["parent_id"] in chosen}
    else:
        scope = {t["id"] for t in targets}

    nodes: dict[str, dict] = {}
    links: list[dict] = []

    def add(nid: str, ntype: str, label: str, **meta) -> str:
        if nid not in nodes:
            nodes[nid] = {"id": nid, "type": ntype, "label": label, **meta}
        return nid

    for tid in scope:
        t = tmap[tid]
        ntype = "subdomain" if t.get("source") == "subdomain" else "target"
        add(f"t{tid}", ntype, t["value"], status=t.get("last_status"))
        pid = t.get("parent_id")
        if pid in scope:
            links.append({"source": f"t{pid}", "target": f"t{tid}", "rel": "subdomain"})

    for tid in scope:
        assets = [a for a in list_assets(conn, tid) if a["status"] == "active"]
        # global IP nodes first
        for a in assets:
            if a["kind"] == "host":
                ipn = add(f"ip:{a['label']}", "ip", a["label"])
                links.append({"source": f"t{tid}", "target": ipn, "rel": "resolves"})
        for a in assets:
            k = a["kind"]
            if k == "host":
                continue
            d = a.get("details") or {}
            new = bool(a["is_new"] and not a["acknowledged"])
            if k == "subdomain":
                child = get_target_by_value(conn, a["label"])
                if child and f"t{child['id']}" in nodes:
                    continue  # represented by its own target node already
                nid = add(f"a{a['id']}", "subdomain", a["label"], is_new=new)
                links.append({"source": f"t{tid}", "target": nid, "rel": "subdomain"})
            elif k == "port":
                nid = add(f"a{a['id']}", "port", a["label"], is_new=new)
                ip = d.get("ip")
                src = f"ip:{ip}" if ip and f"ip:{ip}" in nodes else f"t{tid}"
                links.append({"source": src, "target": nid, "rel": "port"})
            else:
                nid = add(f"a{a['id']}", k, a["label"], is_new=new,
                          public=bool(d.get("public")))
                links.append({"source": f"t{tid}", "target": nid, "rel": k})

    return {"nodes": list(nodes.values()), "links": links}


def technology_summary(conn: sqlite3.Connection, target_ids: list[int] | None = None,
                       q: str | None = None, group_id: int | None = None) -> list[dict]:
    """Aggregate distinct technologies across scope: name, versions, host count."""
    sql = ("SELECT a.*, t.value AS target_value FROM assets a "
           "JOIN targets t ON t.id=a.target_id "
           "WHERE a.kind='tech' AND a.status='active'")
    args: list[Any] = []
    if group_id is not None:
        sql += " AND t.group_id=?"
        args.append(group_id)
    if target_ids:
        expanded = set(target_ids)
        expanded |= {r["id"] for r in conn.execute(
            "SELECT id FROM targets WHERE parent_id IN (%s)" %
            ",".join("?" * len(target_ids)), target_ids)}
        sql += " AND a.target_id IN (%s)" % ",".join("?" * len(expanded))
        args.extend(expanded)
    if q:
        like = f"%{q.strip()}%"
        sql += " AND (a.label LIKE ? OR a.details LIKE ?)"
        args.extend([like, like])
    rows = [row_to_dict(r) for r in conn.execute(sql, args)]

    agg: dict[str, dict] = {}
    for a in rows:
        d = a.get("details") or {}
        name = d.get("name") or a["label"]
        e = agg.setdefault(name, {"name": name, "category": d.get("category", ""),
                                  "versions": set(), "targets": set(),
                                  "evidence": set(), "verified": False, "is_new": False})
        if d.get("version"):
            e["versions"].add(d["version"])
        e["targets"].add(a["target_value"])
        for ev in d.get("evidence", []) or []:
            e["evidence"].add(ev)
        if d.get("verified"):
            e["verified"] = True
        if a["is_new"] and not a["acknowledged"]:
            e["is_new"] = True
        if d.get("category") and not e["category"]:
            e["category"] = d["category"]
    out = []
    for e in agg.values():
        out.append({"name": e["name"], "category": e["category"],
                    "versions": sorted(e["versions"]), "count": len(e["targets"]),
                    "targets": sorted(e["targets"]), "evidence": sorted(e["evidence"]),
                    "verified": e["verified"], "is_new": e["is_new"]})
    out.sort(key=lambda x: (-x["count"], x["name"].lower()))
    return out
