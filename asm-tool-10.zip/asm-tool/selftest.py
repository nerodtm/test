#!/usr/bin/env python3
"""Release smoke-test for the Attack Surface Mapper.

Runs a fast set of checks that catch the kinds of regressions that have bitten
this project before (a lost CSS/JS block, a broken endpoint, a half-applied
edit). Pure standard library — no curl or node required — so it runs anywhere
the app itself runs, including inside the Docker container:

    python selftest.py

Exit code 0 = all good, 1 = something failed.
"""
from __future__ import annotations

import json
import os
import py_compile
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("SELFTEST_PORT", "8391"))
BASE = f"http://127.0.0.1:{PORT}"
ADMIN_USER = "selftest_admin"
ADMIN_PASS = "SelftestPass123"

passes: list[str] = []
fails: list[str] = []


def ok(msg: str) -> None:
    passes.append(msg); print(f"  \033[32mPASS\033[0m  {msg}")


def bad(msg: str) -> None:
    fails.append(msg); print(f"  \033[31mFAIL\033[0m  {msg}")


def check(cond: bool, msg: str) -> None:
    ok(msg) if cond else bad(msg)


# 1) Python compiles ---------------------------------------------------------
print("\n[1] Python sources compile")
for name in ("__init__", "db", "scanner", "auth", "main"):
    path = os.path.join(ROOT, "app", f"{name}.py")
    try:
        py_compile.compile(path, doraise=True)
        ok(f"app/{name}.py compiles")
    except py_compile.PyCompileError as e:
        bad(f"app/{name}.py: {e}")


# 2) Dashboard JS syntax (only if node is available) -------------------------
print("\n[2] Dashboard JavaScript")
html_path = os.path.join(ROOT, "static", "index.html")
html = open(html_path, encoding="utf-8").read()
import re
m = re.search(r"<script>(.*)</script>", html, re.S)
if not m:
    bad("no <script> block found in index.html")
else:
    js = m.group(1)
    node = None
    for cand in ("node", "nodejs"):
        try:
            subprocess.run([cand, "--version"], capture_output=True, check=True)
            node = cand; break
        except Exception:
            continue
    if node:
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False) as f:
            f.write(js); jsfile = f.name
        r = subprocess.run([node, "--check", jsfile], capture_output=True, text=True)
        os.unlink(jsfile)
        check(r.returncode == 0, "dashboard JS parses" + ("" if r.returncode == 0 else f" — {r.stderr.strip()[:200]}"))
    else:
        # fallback: brace/paren balance sanity check
        check(js.count("{") == js.count("}"), "dashboard JS brace balance (node not installed — basic check only)")


# 3) Required UI markers present ---------------------------------------------
print("\n[3] Dashboard UI markers present")
MARKERS = {
    "login overlay": 'id="authOverlay"',
    "account menu": 'id="acctBtn"',
    "user management": 'id="usersModal"',
    "mesh toolbar": 'class="meshtools"',
    "mesh fit button": 'id="fitMesh"',
    "mesh expand button": 'id="expandMesh"',
    "mesh export button": 'id="exportJpg"',
    "report panel": 'class="rmpanel"',
    "inventory filters": 'data-kind="impersonation"',
    "scan-selected picker": 'id="scanSelBtn"',
    "per-target mode": "data-modetarget",
    "default-mode control": 'id="defModeSel"',
}
for label, needle in MARKERS.items():
    check(needle in html, f"{label} ({needle})")


# 4) Boot + live endpoint checks ---------------------------------------------
print("\n[4] Server boots and endpoints behave")
tmpdb = tempfile.mktemp(suffix=".db")
env = dict(os.environ, ASM_DB_PATH=tmpdb, ASM_ADMIN_USER=ADMIN_USER,
           ASM_ADMIN_PASSWORD=ADMIN_PASS, ASM_SCAN_DAILY_AT="")
proc = subprocess.Popen(
    [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(PORT)],
    cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def req(path, method="GET", body=None, cookie=None):
    """Return (status, body_bytes, set_cookie_token). Cookie handled manually
    because http.cookiejar is unreliable for 127.0.0.1 host cookies."""
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    if data:
        r.add_header("Content-Type", "application/json")
    if cookie:
        r.add_header("Cookie", cookie)
    try:
        resp = urllib.request.urlopen(r, timeout=5)
        status, raw, hdrs = resp.status, resp.read(), resp.headers
    except urllib.error.HTTPError as e:
        status, raw, hdrs = e.code, e.read(), e.headers
    token = None
    sc = hdrs.get("Set-Cookie", "") if hdrs else ""
    m2 = re.search(r"asm_session=([^;]+)", sc)
    if m2:
        token = "asm_session=" + m2.group(1)
    return status, raw, token


try:
    ready = False
    for _ in range(40):
        try:
            urllib.request.urlopen(BASE + "/", timeout=2); ready = True; break
        except Exception:
            time.sleep(0.5)
    check(ready, "server responds within timeout")

    if ready:
        st, _, _ = req("/api/stats")
        check(st == 401, "unauthenticated /api/stats is rejected (401)")

        st, _, _ = req("/")
        check(st == 200, "dashboard shell is served (200)")

        st, body, cookie = req("/api/auth/login", "POST",
                               {"username": ADMIN_USER, "password": ADMIN_PASS})
        check(st == 200 and cookie, "admin can log in and receives a session (200)")

        st, _, _ = req("/api/stats", cookie=cookie)
        check(st == 200, "authenticated /api/stats works (200)")

        for ep in ("/api/assets", "/api/issues", "/api/technologies", "/api/graph", "/api/config", "/api/users"):
            st, _, _ = req(ep, cookie=cookie)
            check(st == 200, f"authenticated {ep} works (200)")

        st, _, _ = req("/api/auth/login", "POST", {"username": ADMIN_USER, "password": "wrong"})
        check(st == 401, "wrong password is rejected (401)")

        req("/api/auth/logout", "POST", cookie=cookie)
        st, _, _ = req("/api/stats", cookie=cookie)
        check(st == 401, "session is invalidated after logout (401)")
finally:
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except Exception:
        proc.kill()
    for ext in ("", "-wal", "-shm"):
        try:
            os.remove(tmpdb + ext)
        except OSError:
            pass


# summary --------------------------------------------------------------------
print(f"\n{'='*52}\n  {len(passes)} passed, {len(fails)} failed")
if fails:
    print("  FAILED:")
    for f in fails:
        print(f"   - {f}")
    print("=" * 52)
    sys.exit(1)
print("  All checks passed.\n" + "=" * 52)
sys.exit(0)
