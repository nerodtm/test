# Attack Surface Mapper

A lightweight, self-hostable attack-surface management (ASM) tool. Onboard a
domain or IP, and it inventories the exposed surface — subdomains, DNS records,
name servers, resolved hosts, open ports, technologies and versions, reachable
URLs / API endpoints, the fronting WAF/CDN, the identity provider (Azure AD /
ADFS / Google Workspace), and publicly exposed cloud storage buckets — then
**flags anything new** that appears on the next scan.

Two views: an **Inventory** table and an interactive **Mesh** graph that shows
how everything connects (domains → subdomains → shared IPs → ports, with DNS,
WAF, identity and buckets hanging off each domain).

Built to stay small: one Python service, a single SQLite file, a single-page
dashboard, five dependencies. Discovery of buckets, Azure AD/ADFS, and CT-log
subdomains requires querying the relevant third parties (AWS/Azure/GCP,
Microsoft login, crt.sh); every one of those calls degrades gracefully, so on an
isolated network the tool still runs and simply reports less.

---

## Deploy

### Option A — Docker (recommended)

```bash
docker compose up -d --build
# open http://localhost:8000
```

Scan history persists in the `asm-data` volume across restarts.

### Option B — Run directly

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
# open http://localhost:8000
```

That's the whole install. Python 3.11+.

---

## Use it

1. **Onboard** — type a domain or IP in the left panel and hit *Add & scan*. The
   first scan starts automatically.
2. **Review assets** — ports, technologies, and endpoints appear in the table.
   Filter by type, or scope to a single target by clicking it.
3. **Watch for drift** — on every re-scan, assets that were never seen before are
   flagged **NEW** (amber). Acknowledge them once reviewed; the flag clears.
   Assets that disappear are marked *gone*.

Re-scans run automatically on a schedule (default hourly) and can be triggered
manually with *Scan all* or per-target.

---

## Configuration (environment variables)

| Variable                 | Default            | Meaning                                        |
|--------------------------|--------------------|------------------------------------------------|
| `ASM_SCAN_MODE`          | `passive`          | Default mode for new targets: passive / light / aggressive |
| `ASM_ACTIVE_CONCURRENCY` | `8`                | Max concurrent active probes (light/aggressive) |
| `ASM_ACTIVE_DELAY`       | `0.15`             | Seconds between active probes (throttle)       |
| `ASM_ACTIVE_JITTER`      | `0.25`             | Added random delay up to this many seconds     |
| `ASM_SCAN_INTERVAL_MIN`  | `60`               | Minutes between automatic re-scans             |
| `ASM_RETENTION_DAYS`     | `120`              | Keep scan history + gone assets this many days (0 = forever; active assets never pruned) |
| `ASM_PORTS`              | curated ~50 ports  | Comma-separated port list to scan              |
| `ASM_DB_PATH`            | `data/asm.db`      | SQLite file location                           |
| `ASM_CONNECT_TIMEOUT`    | `1.5`              | Per-port TCP connect timeout (seconds)         |
| `ASM_HTTP_TIMEOUT`       | `8.0`              | HTTP request timeout (seconds)                 |
| `ASM_PORT_CONCURRENCY`   | `200`              | Concurrent port connections per host           |
| `ASM_MAX_SUBDOMAINS`     | `200`              | Max resolving subdomains kept per domain        |
| `ASM_SUBDOMAIN_WORDLIST` | *(built-in list)*  | Extra brute-force labels (comma-separated)       |
| `ASM_BUCKET_NAMES`       | *(derived from domain)* | Extra bucket base names to probe (comma-separated) |
| `ASM_VT_API_KEY`         | *(unset)*          | VirusTotal API key — enables reputation + passive subdomains |
| `ASM_HIBP_API_KEY`       | *(unset)*          | Have I Been Pwned API key — adds exposed-account counts (breach catalogue is keyless) |
| `ASM_DEHASHED_KEY`       | *(unset)*          | DeHashed API key — searches leaked credentials for your domains (paid; metadata only, never plaintext) |
| `ASM_DEHASHED_EMAIL`     | *(unset)*          | DeHashed account email (only if your plan requires basic auth) |
| `ASM_BRAND_MONITOR`      | `1`                | Find external sites impersonating your brand (logo/favicon/name) via Certificate Transparency; set `0` to disable |
| `ASM_BRAND_MAX`          | `40`               | Max impersonation candidates to verify per domain |
| `ASM_SHODAN_API_KEY`     | *(unset)*          | Optional — also find your favicon/logo reused on **any** domain (paid Shodan favicon search) |
| `ASM_DEEP_SCAN`          | *(off)*            | `1` to fetch archived JS from the Wayback Machine and mine endpoints |

---

## Groups / folders

Companies with many domains can organise them into **groups** (folders). Create a
group from the sidebar ("+ Group") or when onboarding a target, and move any
domain into it with the folder button on its row — subdomains follow their
parent automatically. Click a group folder to **scope the whole dashboard**
(inventory, technologies, and mesh) to just that group, and the folder shows a
live count of its domains and new findings. Deleting a group leaves its domains
intact (they just become ungrouped). `POST /api/groups/{id}/scan` re-scans an
entire group at once.

## Scan modes — noise control

Active scanning is what gets scan IPs blocked, so the tool is **passive by
default**. Every target has a mode (set at onboarding, inherited by its
subdomains):

- **passive** (default) — sends *no active traffic to your hosts*. Ports,
  services, and vulnerabilities come from **Shodan InternetDB** (Shodan's own
  scan data, free, keyless); subdomains, endpoints, tech, DNS, WAF, identity, and
  breaches come from the passive sources (crt.sh, VirusTotal, Wayback, HIBP, DNS,
  cert/header reads). At most a single homepage GET is made per apex to read
  headers for tech/WAF fingerprinting.
- **light** — passive, plus a *small, slow, throttled* active layer: a top-ports
  scan (low concurrency + delay/jitter) and probing of only benign, expected
  paths (robots, sitemap, `/api`, `/health`…). No attack-looking payloads.
- **aggressive** — the full active sweep: complete port list, all recon paths,
  the active WAF trigger probe, and nmap cross-check. Noisy — use only where you
  won't be blocked.

Throttling for the active modes is configurable (`ASM_ACTIVE_CONCURRENCY`,
`ASM_ACTIVE_DELAY`, `ASM_ACTIVE_JITTER`). Passive ports are labelled `passive ✓`
in the inventory so you can tell Shodan-sourced findings from actively-verified
ones.

## What it discovers

- **Subdomains** (domain targets only) — passive **Certificate Transparency**
  lookup (crt.sh) plus a self-contained **DNS brute-force**, kept if they resolve.
  Each live subdomain is auto-onboarded as its own target and scanned in full.
- **DNS records** — A, AAAA, MX, TXT, CNAME, SOA (via dnspython).
- **Name servers** — the domain's NS records, tracked separately.
- **WAF / CDN** — the fronting service, identified two ways: **passively** from
  response headers, cookies, and CNAME chains, and **actively** by sending a
  benign WAF-triggering probe and comparing it to a clean baseline, so an active
  WAF is caught (as a block response) even when it hides its headers.
- **Identity provider** — Microsoft 365 / **Azure AD** (Managed) vs **ADFS**
  (Federated, with the federation endpoint URL), plus Google Workspace, detected
  via Microsoft's public user-realm endpoint and DNS (MX/TXT) signals.
- **Exposed cloud storage** — probes **AWS S3**, **Azure Blob**, and **Google
  Cloud Storage** for buckets named after your org, and flags which are
  **publicly listable** vs merely present. Publicly exposed buckets are
  highlighted in red.
- **Hosts** — DNS resolution of the target to one or more IPs.
- **Ports & services** — in passive mode from **Shodan InternetDB** (no packets
  sent); in light/aggressive additionally by a throttled active connect scan.
- **Vulnerabilities (CVEs)** — known CVEs for each IP from Shodan InternetDB,
  passively, as their own `vuln` asset type.
- **Technologies + versions** — fingerprinted from HTTP response **headers,
  set-cookies, page markup, `<meta generator>` tags, and discovered paths**. The
  `Server` and `X-Powered-By` headers are parsed token-by-token, so
  `Apache/2.4.52 (Ubuntu) OpenSSL/1.1.1k mod_wsgi/4.9.4 Python/3.10.6` yields
  four separately-versioned entries. Each finding lists the sources that matched
  plus a confidence score; two or more sources marks it **verified**. Cookie-
  and path-based signatures mean detection still works behind a CDN that strips
  the `Server` header.
- **Endpoints / URLs** — robots.txt / sitemap parsing, shallow crawl, and common
  API-path probing; JSON/GraphQL responses tagged **API**. Historical URLs from
  the **Wayback Machine** are folded in (tagged `wayback`) to surface forgotten
  or retired paths.
- **Passive intelligence** — optional enrichment from **VirusTotal** (needs
  `ASM_VT_API_KEY`), querying four relationships: `/subdomains` (seen
  subdomains), `/urls` (crawled/submitted URLs), `/resolutions` (passive DNS /
  IP history), and `/related_references` (related URLs). VT subdomains are
  DNS-verified before adding; VT URLs and references become endpoints.
- **DNS history** — passive-DNS IP history for the domain (which IPs it has
  resolved to and when), from VirusTotal `/resolutions`. Shown as its own
  `dns_history` asset type, distinct from current live DNS records.
- **Wayback Machine** — historical URLs via the CDX API (no key), folded into
  endpoints tagged `wayback`. With **Deep Scan** enabled (`ASM_DEEP_SCAN=1`) it
  also fetches archived JavaScript files
  (`https://web.archive.org/web/{timestamp}id_/{url}`) and mines them for API
  paths and endpoints that may still be live — a strong way to surface forgotten
  routes.
- **Breach exposure** — which known breaches affected the domain (breach name,
  date, data classes, account counts). The breach-catalogue lookup is **keyless**
  (works out of the box); an exposed-account count is added when
  `ASM_HIBP_API_KEY` is set. Reports breach **metadata only — never passwords or
  plaintext credentials**.

## Cross-verification

Every open port is confirmed by a **second, independent method** before it's
trusted: a TLS handshake for TLS ports, an HTTP response for web ports, or a
fresh stdlib socket otherwise — and by **nmap** as well when it's installed on
the host. A port is marked **verified** only when at least two tools agree, so
transient false positives from a single probe get filtered out. Technologies are
verified the same way, by requiring corroboration from two or more independent
sources. The inventory shows a "✓ N tools / N sources" badge; unverified items
are labelled so you can treat them with appropriate caution.

## Domains &amp; subdomains

The sidebar clubs each apex domain with the subdomains discovered beneath it:
they nest under the parent, collapse with the caret, and the parent's badge sums
new findings across the whole family. Selecting an apex shows the assets of the
domain **and all its subdomains together**; the Target column keeps them grouped
so you can read the family as one surface.

## Finding assets

- **Search** — the search box (above every view) filters across asset name,
  target, kind, and stored details, so `1.25.3`, `nginx`, `443`, `WordPress`, or
  `api.acme.com` all work. In the Tech view it filters the technology rollup.
- **New · 24h** — shows every finding first seen in the **last 24 hours** across
  the current scope. (Different window via `new_hours=` on the API.)

## Views

- **Inventory** — filterable table of every asset. Findings are **grouped under
  their apex domain**, with each subdomain as a collapsible sub-group, so a
  domain and everything discovered beneath it read as one surface.
- **Tech** — a rollup answering "what technologies do we have": each distinct
  technology with the version(s) seen, how many hosts run it, a verified badge,
  and which targets use it. Searchable.
- **Mesh** — force-directed graph of the surface. A **domain picker** (top-right)
  lets you choose exactly which domains to include; **Rescan selected** re-scans
  just those domains (and their subdomains). IP nodes are shared, so subdomains
  on the same infrastructure connect through them. Layer toggles in the legend;
  drag to pan, scroll to zoom, drag a node to pin.

## API

The dashboard is just a client of a small REST API — handy for automation:

```
GET    /api/stats
GET    /api/targets
POST   /api/targets              {"value": "...", "name": "..."}
DELETE /api/targets/{id}
POST   /api/targets/{id}/scan
POST   /api/scan-all
POST   /api/scan-selected            {"target_ids":[...], "include_subs":true}
GET    /api/groups                   # folders with target + new counts
POST   /api/groups                   {"name":"...", "color":"#..."}
PATCH  /api/groups/{id}              {"name":"...", "color":"#..."}
DELETE /api/groups/{id}              # ungroups its targets (targets kept)
POST   /api/targets/{id}/group       {"group_id": 3 | null}
POST   /api/groups/{id}/scan         # rescan a whole group
GET    /api/assets?...&group_id=
GET    /api/technologies?...&group_id=
GET    /api/graph?...&group_id=
POST   /api/assets/{id}/ack
POST   /api/assets/ack-all?target_id=
GET    /api/graph?target_id=  |  ?target_ids=1,2,3   # mesh nodes + links
GET    /api/scans
```

---

## Scope & authorisation

This tool performs **active** connection scanning. Only point it at hosts you
own or have explicit written permission to assess — unauthorised scanning may be
unlawful in your jurisdiction. Findings are indicators to review, not confirmed
vulnerabilities.

## Extending

- Add fingerprints: append to `TECH_SIGNATURES` in `app/scanner.py`.
- Add probe paths: extend `COMMON_PATHS`.
- Widen the port set: set `ASM_PORTS` or edit `DEFAULT_PORTS`.
