"""FastAPI application: REST API + background scheduler + dashboard hosting."""
from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db, scanner, auth

STATIC_DIR = os.path.join(os.path.dirname(__file__), "..", "static")

# automatic scan schedule. By default the tool re-scans every asset once a day
# at midnight (server local time). Set ASM_SCAN_DAILY_AT="HH:MM" to change the
# time. Legacy ASM_SCAN_INTERVAL_MIN still works as a fallback if you prefer a
# fixed interval instead of a daily time (set ASM_SCAN_DAILY_AT="" to use it).
SCAN_DAILY_AT = os.environ.get("ASM_SCAN_DAILY_AT", "00:00").strip()
SCAN_INTERVAL = int(os.environ.get("ASM_SCAN_INTERVAL_MIN", "1440")) * 60
# data retention: keep scan history + gone assets for this many days (0 = forever).
# default 120 days = 4 months. Active assets are never pruned.
RETENTION_DAYS = int(os.environ.get("ASM_RETENTION_DAYS", "120"))

# how many target scans may run at once. Bounded concurrency = much faster fleet
# scans than one-at-a-time, without the overload of firing hundreds simultaneously.
SCAN_CONCURRENCY = max(1, int(os.environ.get("ASM_SCAN_CONCURRENCY", "5")))
_scan_sem = asyncio.Semaphore(SCAN_CONCURRENCY)


async def _scan_guarded(target_id: int) -> None:
    """Run a target scan under the global concurrency limit."""
    async with _scan_sem:
        try:
            await scan_target(target_id)
        except Exception:
            pass
_scan_lock = asyncio.Lock()          # one target scanned at a time (keeps it light)
_running: set[int] = set()


# --- request models --------------------------------------------------------

class TargetIn(BaseModel):
    value: str
    name: str | None = None
    scan_mode: str | None = None
    group_id: int | None = None
    group_name: str | None = None


# --- scan execution --------------------------------------------------------

async def scan_target(target_id: int) -> dict:
    if target_id in _running:
        return {"skipped": True, "reason": "already scanning"}
    _running.add(target_id)
    conn = db.connect()
    try:
        target = db.get_target(conn, target_id)
        if not target:
            raise HTTPException(404, "target not found")

        db.set_target_status(conn, target_id, "scanning")
        scan_id = db.start_scan(conn, target_id)
        scan_start = db.now()

        do_subs = bool(target.get("enumerate_subs", 1)) and not scanner.is_ip(target["value"])
        mode = scanner.valid_mode(target.get("scan_mode"))
        async with _scan_lock:
            try:
                findings = await scanner.run_scan(target["value"], enumerate_subs=do_subs,
                                                  mode=mode)
            except Exception as exc:  # keep the app alive on any scan failure
                db.set_target_status(conn, target_id, "error", scanned=True)
                db.finish_scan(conn, scan_id, "error", 0, 0, f"scan failed: {exc}")
                return {"error": str(exc)}

        new_count = 0
        new_subdomain_targets: list[int] = []

        # subdomains: record as assets under this target, and onboard each as its
        # own (non-recursing) target so it gets a full port/tech/endpoint scan.
        for sub in findings.get("subdomains", []):
            label = sub["host"]
            details = {"ips": sub["ips"], "resolved": len(sub["ips"])}
            if sub.get("via"):
                details["via"] = sub["via"]
            if db.upsert_asset(conn, target_id, "subdomain", sub["host"], label, details):
                new_count += 1
            child = db.get_target_by_value(conn, sub["host"])
            if not child:
                child = db.add_target(conn, sub["host"], name=sub["host"],
                                      enumerate_subs=False, parent_id=target_id,
                                      source="subdomain", scan_mode=mode,
                                      group_id=target.get("group_id"))
                new_subdomain_targets.append(child["id"])

        for ip in findings["hosts"]:
            if db.upsert_asset(conn, target_id, "host", ip, ip, {"ip": ip}):
                new_count += 1

        for p in findings["ports"]:
            key = f"{p['ip']}:{p['port']}"
            risk = scanner.port_risk(p["port"])
            if risk:
                p["risky"] = True
                p["risk_kind"] = risk["kind"]
                p["risk_name"] = risk["name"]
                tag = (f"  [DB · {risk['name']}]" if risk["kind"] == "database"
                       else f"  [RISKY · {risk['name']}]")
            else:
                tag = ""
            label = f"{p['port']}/tcp  {p['service']}{tag}"
            if db.upsert_asset(conn, target_id, "port", key, label, p):
                new_count += 1

        for t in findings["techs"]:
            ver = f" {t['version']}" if t.get("version") else ""
            label = f"{t['name']}{ver}"
            if db.upsert_asset(conn, target_id, "tech", t["name"], label, t):
                new_count += 1

        for ep in findings["endpoints"]:
            label = ep["url"]
            if db.upsert_asset(conn, target_id, "endpoint", ep["url"], label, ep):
                new_count += 1

        # DNS records (A/AAAA/MX/TXT/CNAME/SOA — NS handled separately below)
        for rtype, values in findings.get("dns", {}).items():
            if rtype == "NS":
                continue
            for v in values:
                key = f"{rtype}:{v}"
                label = f"{rtype}  {v}"
                if db.upsert_asset(conn, target_id, "dns", key, label,
                                   {"type": rtype, "value": v}):
                    new_count += 1

        for ns in findings.get("nameservers", []):
            if db.upsert_asset(conn, target_id, "ns", ns, f"NS  {ns}", {"host": ns}):
                new_count += 1

        for w in findings.get("waf", []):
            label = f"{w['name']}"
            if db.upsert_asset(conn, target_id, "waf", w["name"], label, w):
                new_count += 1

        for idp in findings.get("idp", []):
            key = idp["provider"]
            label = f"{idp['provider']}" + (f" — {idp.get('mode')}" if idp.get("mode") else "")
            if db.upsert_asset(conn, target_id, "idp", key, label, idp):
                new_count += 1
            # federation server (ADFS/STS host from the realm AuthURL): record it
            # as a host finding AND onboard it as its own scannable target.
            fh = idp.get("federation_host")
            if fh and not scanner.is_ip(fh):
                if db.upsert_asset(conn, target_id, "host", fh,
                                   f"{fh} (federation server)",
                                   {"host": fh, "role": "federation", "source": "adfs-realm"}):
                    new_count += 1
                if not db.get_target_by_value(conn, fh):
                    child = db.add_target(conn, fh, name=fh, enumerate_subs=False,
                                          parent_id=target_id, source="federation",
                                          scan_mode=mode, group_id=target.get("group_id"))
                    new_subdomain_targets.append(child["id"])

        for b in findings.get("buckets", []):
            label = ("PUBLIC " if b["public"] else "") + b["url"]
            if db.upsert_asset(conn, target_id, "bucket", b["url"], label, b):
                new_count += 1

        # breach / leaked-credential exposure (HIBP + DeHashed) — metadata only
        for br in findings.get("breaches", []):
            key = br.get("breach") or br.get("title") or "breach"
            if br.get("source") == "dehashed":
                wc = br.get("with_credentials", 0)
                label = (f"Leaked credentials — {br.get('exposures', 0):,} records"
                         + (f", {wc:,} with passwords" if wc else ""))
            else:
                acct = f" — {br['accounts']:,} accounts" if br.get("accounts") else ""
                label = f"{br.get('title') or key}{acct}"
            if db.upsert_asset(conn, target_id, "breach", key, label, br):
                new_count += 1

        # VirusTotal reputation — flag only if flagged malicious/suspicious
        vt = (findings.get("passive") or {}).get("virustotal") or {}
        rep = vt.get("reputation")
        if rep and (rep.get("malicious") or rep.get("suspicious")):
            label = f"VT: {rep.get('malicious',0)} malicious / {rep.get('suspicious',0)} suspicious"
            if db.upsert_asset(conn, target_id, "intel", "vt-reputation", label,
                               {"source": "virustotal", **rep,
                                "categories": vt.get("categories", {})}):
                new_count += 1

        # passive DNS / IP history (VirusTotal resolutions)
        for res in findings.get("dns_history", []):
            ip = res.get("ip")
            if not ip:
                continue
            dt = f" (seen {res['date']})" if res.get("date") else ""
            if db.upsert_asset(conn, target_id, "dns_history", ip, f"{ip}{dt}", res):
                new_count += 1

        # passive vulnerabilities (Shodan InternetDB CVEs)
        for v in findings.get("vulns", []):
            key = f"{v['ip']}:{v['cve']}"
            if db.upsert_asset(conn, target_id, "vuln", key, f"{v['cve']}", v):
                new_count += 1

        # look-alike / typosquat domains (DNS-validated, registered only)
        for la in findings.get("lookalikes", []):
            risk = la.get("risk", "low")
            tag = {"high": "HIGH", "medium": "med", "low": "parked", "owned": "yours"}.get(risk, risk)
            sig = ""
            if la.get("http_live"):
                sig += " · HTTP"
            if la.get("mx"):
                sig += " · MX"
            label = f"{la['domain']} [{tag}]{sig}"
            if db.upsert_asset(conn, target_id, "lookalike", la["domain"], label, la):
                new_count += 1

        # brand impersonation — external sites using the brand name/logo/favicon
        for im in findings.get("impersonations", []):
            ev = ", ".join(im.get("evidence", [])[:2])
            label = f"{im['domain']} — {ev}" if ev else im["domain"]
            if db.upsert_asset(conn, target_id, "impersonation", im["domain"], label, im):
                new_count += 1

        # email security posture (SPF/DKIM/DMARC/DNSSEC/MTA-STS)
        for em in findings.get("email", []):
            label = f"{em['kind']} — {em.get('status','')}"
            if db.upsert_asset(conn, target_id, "email", em["kind"], label, em):
                new_count += 1

        # TLS certificate intelligence
        for c in findings.get("certs", []):
            state = ("EXPIRED" if c.get("expired") else
                     f"expires in {c['days_to_expiry']}d" if c.get("expiring_soon") else
                     f"valid to {c.get('not_after','')}")
            label = f"{c.get('subject_cn') or c.get('host')} — {state}"
            if db.upsert_asset(conn, target_id, "cert", c.get("host", "cert"), label, c):
                new_count += 1

        # subdomain takeover (verified)
        for to in findings.get("takeover", []):
            label = f"TAKEOVER: {to['domain']} → {to['service']}"
            if db.upsert_asset(conn, target_id, "takeover", to["domain"], label, to):
                new_count += 1

        gone_count = db.mark_stale_gone(conn, target_id, scan_start)
        subs = findings.get("subdomains", [])
        sub_txt = f", {len(subs)} subdomains" if do_subs else ""
        br = findings.get("breaches", [])
        br_txt = f", {len(br)} breaches" if br else ""
        vl = findings.get("vulns", [])
        vl_txt = f", {len(vl)} vulns" if vl else ""
        la = findings.get("lookalikes", [])
        la_txt = f", {len(la)} look-alikes" if la else ""
        summary = (f"[{mode}] {len(findings['hosts'])} hosts, {len(findings['ports'])} ports, "
                   f"{len(findings['techs'])} techs, {len(findings['endpoints'])} endpoints"
                   + sub_txt + br_txt + vl_txt + la_txt)
        db.finish_scan(conn, scan_id, "ok", new_count, gone_count, summary)
        db.set_target_status(conn, target_id, "ok", scanned=True)
        result = {"new": new_count, "gone": gone_count, "summary": summary}
    finally:
        conn.close()
        _running.discard(target_id)

    # scan freshly-discovered subdomains (outside the lock/connection above)
    for child_id in new_subdomain_targets:
        asyncio.create_task(_scan_guarded(child_id))
    return result


def _seconds_until_daily(hhmm: str) -> float:
    """Seconds from now until the next occurrence of HH:MM (server local time)."""
    import datetime
    try:
        hh, mm = (int(x) for x in hhmm.split(":"))
    except Exception:
        hh, mm = 0, 0
    now = datetime.datetime.now()
    target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if target <= now:
        target += datetime.timedelta(days=1)
    return max(1.0, (target - now).total_seconds())


async def scheduler_loop() -> None:
    """Automatic re-scan of every enabled asset. Runs once a day at
    ASM_SCAN_DAILY_AT (default midnight); falls back to a fixed interval if that
    is cleared. Data retention is applied after each run."""
    while True:
        if SCAN_DAILY_AT:
            await asyncio.sleep(_seconds_until_daily(SCAN_DAILY_AT))
        else:
            await asyncio.sleep(SCAN_INTERVAL)
        conn = db.connect()
        targets = [t for t in db.list_targets(conn) if t["enabled"]]
        conn.close()
        # scan up to SCAN_CONCURRENCY targets at once (semaphore-bounded)
        await asyncio.gather(*[_scan_guarded(t["id"]) for t in targets])
        # data retention (trim scan history + long-gone assets)
        try:
            conn = db.connect()
            db.prune(conn, RETENTION_DAYS)
            conn.close()
        except Exception:
            pass
        # guard against re-firing within the same minute for the daily schedule
        if SCAN_DAILY_AT:
            await asyncio.sleep(61)


def _bootstrap_admin() -> None:
    """On first run (no users), create an admin account. Password comes from
    ASM_ADMIN_PASSWORD, or a strong random one is generated and logged."""
    conn = db.connect()
    try:
        if db.count_users(conn) > 0:
            return
        username = os.environ.get("ASM_ADMIN_USER", "admin").strip() or "admin"
        password = os.environ.get("ASM_ADMIN_PASSWORD", "").strip()
        generated = False
        if not password or auth.password_policy_error(password):
            import secrets
            password = secrets.token_urlsafe(12) + "aA1"
            generated = True
        db.create_user(conn, username, auth.hash_password(password),
                       role="admin", must_change_pw=1 if generated else 0)
        banner = "=" * 64
        print(f"\n{banner}\n[ASM] Created initial admin account.\n"
              f"      username: {username}\n"
              f"      password: {password}\n"
              + ("      (randomly generated — set ASM_ADMIN_PASSWORD to choose your own,\n"
                 "       and change it after first login)\n" if generated else
                 "      (from ASM_ADMIN_PASSWORD)\n")
              + f"{banner}\n", flush=True)
    finally:
        conn.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    _bootstrap_admin()
    try:
        conn = db.connect()
        db.prune(conn, RETENTION_DAYS)
        db.prune_sessions(conn)
        conn.close()
    except Exception:
        pass
    task = asyncio.create_task(scheduler_loop())
    yield
    task.cancel()


app = FastAPI(title="Attack Surface Mapper", version="1.0", lifespan=lifespan)


# --- authentication --------------------------------------------------------

# API paths reachable without a session (everything else under /api requires one)
_PUBLIC_API = {"/api/auth/login", "/api/auth/me"}


def _session_user(request: Request) -> dict | None:
    token = request.cookies.get(auth.COOKIE_NAME)
    if not token:
        return None
    conn = db.connect()
    try:
        return db.get_session_user(conn, token)
    finally:
        conn.close()


@app.middleware("http")
async def auth_guard(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api/") and path not in _PUBLIC_API:
        user = _session_user(request)
        if not user:
            return JSONResponse({"detail": "authentication required"}, status_code=401)
        request.state.user = user
    return await call_next(request)


def require_admin(request: Request) -> dict:
    user = getattr(request.state, "user", None)
    if not user or user.get("role") != "admin":
        raise HTTPException(403, "administrator access required")
    return user


class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/auth/login")
def login(body: LoginIn, response: Response):
    from datetime import datetime, timezone, timedelta
    conn = db.connect()
    try:
        user = db.get_user_by_name(conn, body.username.strip())
        if not user or user["disabled"] or not auth.verify_password(body.password, user["pw_hash"]):
            raise HTTPException(401, "invalid username or password")
        token = auth.new_token()
        expires = datetime.now(timezone.utc) + timedelta(hours=auth.SESSION_HOURS)
        db.create_session(conn, token, user["id"], expires.isoformat())
        db.touch_login(conn, user["id"])
        db.prune_sessions(conn)
    finally:
        conn.close()
    response.set_cookie(auth.COOKIE_NAME, token, httponly=True, samesite="lax",
                        secure=auth.COOKIE_SECURE, max_age=auth.SESSION_HOURS * 3600)
    return {"username": user["username"], "role": user["role"],
            "must_change_pw": bool(user["must_change_pw"])}


@app.post("/api/auth/logout")
def logout(request: Request, response: Response):
    token = request.cookies.get(auth.COOKIE_NAME)
    if token:
        conn = db.connect()
        try:
            db.delete_session(conn, token)
        finally:
            conn.close()
    response.delete_cookie(auth.COOKIE_NAME)
    return {"ok": True}


@app.get("/api/auth/me")
def whoami(request: Request):
    user = _session_user(request)
    if not user:
        return JSONResponse({"detail": "not authenticated"}, status_code=401)
    return {"username": user["username"], "role": user["role"],
            "must_change_pw": bool(user["must_change_pw"]),
            "password_policy": auth.policy_description()}


class ChangePwIn(BaseModel):
    current_password: str | None = None
    new_password: str


@app.post("/api/auth/change-password")
def change_password(body: ChangePwIn, request: Request):
    user = request.state.user
    err = auth.password_policy_error(body.new_password)
    if err:
        raise HTTPException(400, err)
    conn = db.connect()
    try:
        full = db.get_user(conn, user["id"])
        # current password required unless the account is flagged must_change_pw
        if not full["must_change_pw"]:
            if not body.current_password or not auth.verify_password(body.current_password, full["pw_hash"]):
                raise HTTPException(400, "current password is incorrect")
        db.set_user_password(conn, user["id"], auth.hash_password(body.new_password), 0)
    finally:
        conn.close()
    return {"ok": True}


# --- user management (admin only) ------------------------------------------

class NewUserIn(BaseModel):
    username: str
    password: str
    role: str = "user"


@app.get("/api/users")
def api_list_users(request: Request):
    require_admin(request)
    conn = db.connect()
    try:
        return db.list_users(conn)
    finally:
        conn.close()


@app.post("/api/users")
def api_create_user(body: NewUserIn, request: Request):
    require_admin(request)
    if not auth.valid_username(body.username):
        raise HTTPException(400, "username must be 3–40 chars: letters, digits, . _ -")
    err = auth.password_policy_error(body.password)
    if err:
        raise HTTPException(400, err)
    role = "admin" if body.role == "admin" else "user"
    conn = db.connect()
    try:
        if db.get_user_by_name(conn, body.username):
            raise HTTPException(409, "username already exists")
        u = db.create_user(conn, body.username, auth.hash_password(body.password),
                           role=role, must_change_pw=1)
    finally:
        conn.close()
    return {"id": u["id"], "username": u["username"], "role": u["role"]}


class ResetPwIn(BaseModel):
    new_password: str


@app.post("/api/users/{user_id}/reset-password")
def api_reset_password(user_id: int, body: ResetPwIn, request: Request):
    require_admin(request)
    err = auth.password_policy_error(body.new_password)
    if err:
        raise HTTPException(400, err)
    conn = db.connect()
    try:
        if not db.get_user(conn, user_id):
            raise HTTPException(404, "user not found")
        # force the user to set their own password on next login
        db.set_user_password(conn, user_id, auth.hash_password(body.new_password), 1)
        conn.execute("DELETE FROM sessions WHERE user_id=?", (user_id,)); conn.commit()
    finally:
        conn.close()
    return {"ok": True}


@app.post("/api/users/{user_id}/disable")
def api_disable_user(user_id: int, request: Request, disabled: bool = True):
    admin = require_admin(request)
    if user_id == admin["id"] and disabled:
        raise HTTPException(400, "you cannot disable your own account")
    conn = db.connect()
    try:
        db.set_user_disabled(conn, user_id, 1 if disabled else 0)
    finally:
        conn.close()
    return {"ok": True}


@app.delete("/api/users/{user_id}")
def api_delete_user(user_id: int, request: Request):
    admin = require_admin(request)
    if user_id == admin["id"]:
        raise HTTPException(400, "you cannot delete your own account")
    conn = db.connect()
    try:
        if not db.get_user(conn, user_id):
            raise HTTPException(404, "user not found")
        db.delete_user(conn, user_id)
    finally:
        conn.close()
    return {"ok": True}


# --- API -------------------------------------------------------------------

@app.post("/api/prune")
def run_prune():
    """Manually apply data retention now. Returns how many rows were removed."""
    conn = db.connect()
    try:
        return db.prune(conn, RETENTION_DAYS)
    finally:
        conn.close()

@app.get("/api/stats")
def get_stats():
    conn = db.connect()
    try:
        return db.stats(conn)
    finally:
        conn.close()


@app.get("/api/targets")
def get_targets():
    conn = db.connect()
    try:
        return db.list_targets(conn)
    finally:
        conn.close()


@app.post("/api/targets")
async def create_target(body: TargetIn):
    value = body.value.strip()
    if not value:
        raise HTTPException(400, "value is required")
    conn = db.connect()
    try:
        gid = body.group_id
        if gid is None and body.group_name:
            gid = db.add_group(conn, body.group_name)["id"]
        # mode precedence: explicit request → saved dashboard default → env default
        mode = body.scan_mode or db.get_setting(conn, "default_scan_mode", None)
        target = db.add_target(conn, value, body.name,
                               scan_mode=scanner.valid_mode(mode),
                               group_id=gid)
    finally:
        conn.close()
    # kick off an immediate first scan in the background
    asyncio.create_task(_scan_guarded(target["id"]))
    return target


class ModeIn(BaseModel):
    scan_mode: str


@app.post("/api/targets/{target_id}/mode")
def set_target_scan_mode(target_id: int, body: ModeIn):
    mode = scanner.valid_mode(body.scan_mode)
    conn = db.connect()
    try:
        if not db.get_target(conn, target_id):
            raise HTTPException(404, "target not found")
        db.set_target_mode(conn, target_id, mode)
        # a target's subdomains inherit its mode
        for t in db.list_targets(conn):
            if t["parent_id"] == target_id:
                db.set_target_mode(conn, t["id"], mode)
    finally:
        conn.close()
    return {"target_id": target_id, "scan_mode": mode}


class DefaultModeIn(BaseModel):
    scan_mode: str
    apply_all: bool = False
    group_id: int | None = None


@app.get("/api/config")
def get_config():
    conn = db.connect()
    try:
        return {"default_scan_mode":
                scanner.valid_mode(db.get_setting(conn, "default_scan_mode", None))}
    finally:
        conn.close()


@app.post("/api/config/scan-mode")
def set_default_scan_mode(body: DefaultModeIn):
    mode = scanner.valid_mode(body.scan_mode)
    conn = db.connect()
    try:
        db.set_setting(conn, "default_scan_mode", mode)
        updated = 0
        if body.apply_all:
            updated = db.set_all_modes(conn, mode, body.group_id)
    finally:
        conn.close()
    return {"default_scan_mode": mode, "updated": updated}


@app.delete("/api/targets/{target_id}")
def remove_target(target_id: int):
    conn = db.connect()
    try:
        db.delete_target(conn, target_id)
    finally:
        conn.close()
    return {"deleted": target_id}


class GroupIn(BaseModel):
    name: str
    color: str | None = None


class GroupAssign(BaseModel):
    group_id: int | None = None


@app.get("/api/groups")
def get_groups():
    conn = db.connect()
    try:
        return db.list_groups(conn)
    finally:
        conn.close()


@app.post("/api/groups")
def create_group(body: GroupIn):
    if not body.name.strip():
        raise HTTPException(400, "name is required")
    conn = db.connect()
    try:
        return db.add_group(conn, body.name, body.color)
    finally:
        conn.close()


@app.patch("/api/groups/{group_id}")
def update_group(group_id: int, body: GroupIn):
    conn = db.connect()
    try:
        db.rename_group(conn, group_id, body.name, body.color)
    finally:
        conn.close()
    return {"updated": group_id}


@app.delete("/api/groups/{group_id}")
def remove_group(group_id: int):
    conn = db.connect()
    try:
        db.delete_group(conn, group_id)
    finally:
        conn.close()
    return {"deleted": group_id}


@app.post("/api/targets/{target_id}/group")
def assign_target_group(target_id: int, body: GroupAssign):
    conn = db.connect()
    try:
        db.set_target_group(conn, target_id, body.group_id)
    finally:
        conn.close()
    return {"target": target_id, "group_id": body.group_id}


@app.post("/api/groups/{group_id}/scan")
async def scan_group(group_id: int):
    conn = db.connect()
    ids = [t["id"] for t in db.list_targets(conn) if t.get("group_id") == group_id]
    conn.close()
    for tid in ids:
        asyncio.create_task(_scan_guarded(tid))
    return {"queued": ids}


@app.post("/api/targets/{target_id}/scan")
async def trigger_scan(target_id: int):
    return await scan_target(target_id)


@app.post("/api/scan-all")
async def scan_all():
    conn = db.connect()
    targets = [t for t in db.list_targets(conn) if t["enabled"]]
    conn.close()
    for t in targets:
        asyncio.create_task(_scan_guarded(t["id"]))
    return {"queued": [t["id"] for t in targets]}


class ScanSelection(BaseModel):
    target_ids: list[int]
    include_subs: bool = True
    scan_mode: str | None = None      # optional: run these in a specific mode


@app.post("/api/scan-selected")
async def scan_selected(body: ScanSelection):
    """Re-scan only the chosen domains (and, by default, their subdomains).
    If scan_mode is given, those targets are switched to that mode first."""
    conn = db.connect()
    all_targets = db.list_targets(conn)
    chosen = set(body.target_ids)
    queued = set(chosen)
    if body.include_subs:
        queued |= {t["id"] for t in all_targets if t["parent_id"] in chosen}
    if body.scan_mode:
        mode = scanner.valid_mode(body.scan_mode)
        for tid in queued:
            db.set_target_mode(conn, tid, mode)
    conn.close()
    for tid in queued:
        asyncio.create_task(_scan_guarded(tid))
    return {"queued": sorted(queued)}


@app.get("/api/assets")
def get_assets(target_id: int | None = None, kind: str | None = None,
               new_only: bool = False, family: bool = False,
               q: str | None = None, new_hours: int | None = None,
               group_id: int | None = None):
    conn = db.connect()
    try:
        return db.list_assets(conn, target_id, kind, new_only, family, q, new_hours, group_id)
    finally:
        conn.close()


@app.post("/api/assets/{asset_id}/ack")
def ack_asset(asset_id: int):
    conn = db.connect()
    try:
        db.acknowledge_asset(conn, asset_id)
    finally:
        conn.close()
    return {"acknowledged": asset_id}


@app.post("/api/assets/ack-all")
def ack_all(target_id: int | None = None):
    conn = db.connect()
    try:
        n = db.acknowledge_all(conn, target_id)
    finally:
        conn.close()
    return {"acknowledged": n}


@app.get("/api/graph")
def get_graph(target_id: int | None = None, target_ids: str | None = None,
              group_id: int | None = None):
    ids = None
    if target_ids:
        ids = [int(x) for x in target_ids.split(",") if x.strip().isdigit()]
    elif target_id is not None:
        ids = [target_id]
    conn = db.connect()
    try:
        return db.graph(conn, ids, group_id)
    finally:
        conn.close()


@app.get("/api/report/{target_id}")
def get_report(target_id: int):
    """Consolidated report for a target and all its subdomains."""
    conn = db.connect()
    try:
        target = db.get_target(conn, target_id)
        if not target:
            raise HTTPException(404, "target not found")
        all_targets = db.list_targets(conn)
        children = [t for t in all_targets if t.get("parent_id") == target_id]
        group = None
        if target.get("group_id"):
            group = next((g for g in db.list_groups(conn)
                          if g["id"] == target["group_id"]), None)
        # family assets (this target + its subdomains), already carry target_value
        assets = db.list_assets(conn, target_id, family=True)
        summary: dict[str, int] = {}
        for a in assets:
            summary[a["kind"]] = summary.get(a["kind"], 0) + 1
        new_count = sum(1 for a in assets if a["is_new"] and not a["acknowledged"])
        return {
            "target": target,
            "group": group,
            "generated_at": db.now(),
            "subdomains": [
                {"value": c["value"], "last_status": c.get("last_status"),
                 "last_scan_at": c.get("last_scan_at")}
                for c in sorted(children, key=lambda x: x["value"])
            ],
            "summary": summary,
            "new_count": new_count,
            "asset_total": len(assets),
            "assets": assets,
        }
    finally:
        conn.close()


@app.get("/api/issues")
def get_issues(group_id: int | None = None, target_id: int | None = None):
    conn = db.connect()
    try:
        return db.top_issues(conn, group_id, target_id)
    finally:
        conn.close()


@app.get("/api/technologies")
def get_technologies(target_ids: str | None = None, q: str | None = None,
                     group_id: int | None = None):
    ids = [int(x) for x in target_ids.split(",") if x.strip().isdigit()] if target_ids else None
    conn = db.connect()
    try:
        return db.technology_summary(conn, ids, q, group_id)
    finally:
        conn.close()


@app.get("/api/scans")
def get_scans():
    conn = db.connect()
    try:
        return db.recent_scans(conn)
    finally:
        conn.close()


# --- dashboard -------------------------------------------------------------

@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
