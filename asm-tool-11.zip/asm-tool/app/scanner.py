"""Lightweight, dependency-light scanning engine.

Per target:
  0. subs    -> (domains only) enumerate subdomains: Certificate Transparency
                logs (crt.sh) + DNS brute-force, then keep the ones that resolve
  1. hosts   -> resolve the target to one or more IPs
  2. ports   -> async TCP connect scan over a curated port list, grab banners
  3. web     -> on open HTTP/S ports: fingerprint tech + versions, discover
                endpoints (robots.txt, sitemap.xml, common API paths, shallow crawl)

Everything is stdlib + httpx. The only outbound call to a third party is the
optional Certificate Transparency lookup (crt.sh) during subdomain discovery;
if it is unreachable (e.g. an isolated network) the scan falls back cleanly to
the self-contained DNS brute-force. Ports, tech and endpoint scanning only ever
touch the targets themselves.
"""
from __future__ import annotations

import asyncio
import re
import socket
import ssl
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import httpx

# --- configuration ---------------------------------------------------------

# Curated "interesting" TCP ports. Override with ASM_PORTS env (comma list).
DEFAULT_PORTS = [
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 389, 443, 445, 465,
    587, 993, 995, 1433, 1521, 2049, 2375, 2376, 3000, 3306, 3389, 4444,
    5000, 5432, 5601, 5672, 5900, 5985, 6379, 7001, 8000, 8008, 8080, 8081,
    8088, 8443, 8888, 9000, 9042, 9092, 9200, 9300, 11211, 15672, 27017,
    2181, 5984, 7000, 8086, 8123, 26257, 27018, 28015, 5439,
]

WEB_PORTS = {80, 443, 3000, 5000, 8000, 8008, 8080, 8081, 8088, 8443, 8888, 9000}
TLS_PORTS = {443, 8443, 9443}

# Internet-exposed database ports — always worth calling out explicitly.
DB_PORTS = {
    1433: "MSSQL", 1521: "Oracle", 3306: "MySQL", 5432: "PostgreSQL",
    6379: "Redis", 9042: "Cassandra", 7000: "Cassandra", 9200: "Elasticsearch",
    9300: "Elasticsearch", 11211: "Memcached", 27017: "MongoDB", 27018: "MongoDB",
    5984: "CouchDB", 8086: "InfluxDB", 26257: "CockroachDB", 2181: "ZooKeeper",
    9000: "ClickHouse", 5439: "Redshift", 8123: "ClickHouse", 28015: "RethinkDB",
}
# Other high-risk management / file / remote-access ports.
RISKY_PORTS = {
    21: "FTP", 23: "Telnet", 25: "SMTP-open", 135: "MSRPC", 139: "NetBIOS",
    445: "SMB", 512: "rexec", 513: "rlogin", 514: "rsh", 873: "rsync",
    2049: "NFS", 2375: "Docker-API", 2376: "Docker-API", 3389: "RDP",
    5900: "VNC", 5985: "WinRM", 5986: "WinRM", 10250: "Kubelet", 4444: "Metasploit",
}


def port_risk(port: int) -> dict | None:
    """Classify a port. Returns {kind, name} for DB/risky ports, else None."""
    if port in DB_PORTS:
        return {"kind": "database", "name": DB_PORTS[port]}
    if port in RISKY_PORTS:
        return {"kind": "risky", "name": RISKY_PORTS[port]}
    return None


COMMON_PATHS = [
    "/robots.txt", "/sitemap.xml", "/.well-known/security.txt",
    "/api", "/api/v1", "/api/v2", "/graphql", "/graphiql",
    "/swagger.json", "/swagger-ui.html", "/openapi.json", "/v2/api-docs",
    "/health", "/healthz", "/status", "/metrics", "/actuator", "/actuator/health",
    "/.git/config", "/.env", "/admin", "/login", "/wp-json", "/wp-login.php",
    "/server-status", "/phpinfo.php", "/debug", "/.well-known/openid-configuration",
]

# Transparent fingerprint signatures. Each looks at a "source" (header:<name>,
# cookie, or body) and optionally extracts a version group. Detection records
# every source that matched, so a tech confirmed by >=2 sources is "verified".
TECH_SIGNATURES = [
    # (name, category, source, pattern, version_group_or_None)
    # -- web servers / proxies (Server header) --
    ("nginx", "web-server", "header:server", r"nginx(?:/([\d.]+))?", 1),
    ("Apache", "web-server", "header:server", r"apache(?:/([\d.]+))?", 1),
    ("Microsoft-IIS", "web-server", "header:server", r"microsoft-iis(?:/([\d.]+))?", 1),
    ("LiteSpeed", "web-server", "header:server", r"litespeed", None),
    ("Caddy", "web-server", "header:server", r"caddy", None),
    ("Envoy", "proxy", "header:server", r"envoy", None),
    ("Tomcat", "app-server", "header:server", r"tomcat", None),
    ("Jetty", "app-server", "header:server", r"jetty(?:\(([\d.]+))?", 1),
    ("Gunicorn", "app-server", "header:server", r"gunicorn(?:/([\d.]+))?", 1),
    ("Werkzeug", "app-server", "header:server", r"werkzeug(?:/([\d.]+))?", 1),
    ("Kestrel", "app-server", "header:server", r"kestrel", None),
    ("openresty", "web-server", "header:server", r"openresty(?:/([\d.]+))?", 1),
    ("Cowboy", "app-server", "header:server", r"cowboy", None),
    ("Varnish", "cache", "header:via", r"varnish", None),
    ("Varnish", "cache", "header:x-varnish", r".+", None),
    # -- languages / frameworks (X-Powered-By and friends) --
    ("Express", "framework", "header:x-powered-by", r"express", None),
    ("PHP", "language", "header:x-powered-by", r"php(?:/([\d.]+))?", 1),
    ("ASP.NET", "framework", "header:x-powered-by", r"asp\.net", None),
    ("ASP.NET", "framework", "header:x-aspnet-version", r"([\d.]+)", 1),
    ("ASP.NET MVC", "framework", "header:x-aspnetmvc-version", r"([\d.]+)", 1),
    ("Next.js", "framework", "header:x-powered-by", r"next\.js", None),
    ("Nuxt.js", "framework", "header:x-powered-by", r"nuxt", None),
    ("Servlet", "framework", "header:x-powered-by", r"servlet(?:/([\d.]+))?", 1),
    ("PleskLin", "hosting", "header:x-powered-by", r"plesk", None),
    ("Phusion Passenger", "app-server", "header:x-powered-by", r"phusion passenger(?:\s*([\d.]+))?", 1),
    ("Ruby on Rails", "framework", "header:x-powered-by", r"rails", None),
    # -- CMS / platforms --
    ("WordPress", "cms", "body", r'<meta name="generator" content="WordPress ([\d.]+)"', 1),
    ("WordPress", "cms", "body", r'/wp-content/|/wp-includes/', None),
    ("Drupal", "cms", "header:x-generator", r"drupal(?:\s*([\d.]+))?", 1),
    ("Drupal", "cms", "header:x-drupal-cache", r".+", None),
    ("Drupal", "cms", "body", r'<meta name="Generator" content="Drupal', None),
    ("Joomla", "cms", "body", r'<meta name="generator" content="Joomla', None),
    ("Ghost", "cms", "body", r'<meta name="generator" content="Ghost ([\d.]+)"', 1),
    ("Shopify", "ecommerce", "header:x-shopid", r".+", None),
    ("Shopify", "ecommerce", "header:x-shopify-stage", r".+", None),
    ("Magento", "ecommerce", "cookie", r"X-Magento-|frontend=", None),
    ("WooCommerce", "ecommerce", "body", r'woocommerce', None),
    ("Wix", "website-builder", "header:x-wix-request-id", r".+", None),
    ("Squarespace", "website-builder", "header:x-servedby", r"squarespace", None),
    ("Webflow", "website-builder", "body", r'data-wf-|webflow', None),
    ("HubSpot", "marketing", "body", r'hs-scripts\.com|hubspot', None),
    ("Contentful", "cms", "body", r'contentful', None),
    # -- JS / CSS frameworks (body) --
    ("React", "js-library", "body", r'<div id="root"|data-reactroot|react(?:\.min)?\.js', None),
    ("Vue.js", "js-library", "body", r'data-v-[0-9a-f]{8}|__vue__|vue(?:\.min)?\.js', None),
    ("Angular", "js-library", "body", r'ng-version="([\d.]+)"', 1),
    ("AngularJS", "js-library", "body", r'ng-app|angular(?:\.min)?\.js', None),
    ("Next.js", "framework", "body", r'/_next/static/|__NEXT_DATA__', None),
    ("Nuxt.js", "framework", "body", r'__NUXT__|/_nuxt/', None),
    ("Gatsby", "framework", "body", r'___gatsby|/page-data/', None),
    ("Svelte", "js-library", "body", r'svelte-[0-9a-z]{6}', None),
    ("jQuery", "js-library", "body", r'jquery[.-]([\d.]+)(?:\.min)?\.js', 1),
    ("Bootstrap", "css-framework", "body", r'bootstrap[.-]([\d.]+)(?:\.min)?\.css', 1),
    ("Tailwind CSS", "css-framework", "body", r'tailwind', None),
    ("Font Awesome", "font-script", "body", r'font-?awesome', None),
    ("Google Analytics", "analytics", "body", r'google-analytics\.com|gtag\(|GTM-[A-Z0-9]+', None),
    ("Cloudflare Insights", "analytics", "body", r'cloudflareinsights', None),
    # -- cookie-based (very reliable through CDNs) --
    ("PHP", "language", "cookie", r"PHPSESSID", None),
    ("Java", "language", "cookie", r"JSESSIONID", None),
    ("ASP.NET", "framework", "cookie", r"ASP\.NET_SessionId|\.ASPXAUTH", None),
    ("Laravel", "framework", "cookie", r"laravel_session|XSRF-TOKEN", None),
    ("Django", "framework", "cookie", r"csrftoken|django", None),
    ("Ruby on Rails", "framework", "cookie", r"_session_id|_rails", None),
    ("Express", "framework", "cookie", r"connect\.sid", None),
    ("CodeIgniter", "framework", "cookie", r"ci_session", None),
    ("Flask", "framework", "cookie", r"\bsession=eyJ", None),
    ("WordPress", "cms", "cookie", r"wordpress_|wp-settings", None),
    # -- infra / tooling / panels --
    ("Grafana", "monitoring", "body", r'grafana', None),
    ("Kibana", "monitoring", "header:kbn-name", r".+", None),
    ("Prometheus", "monitoring", "body", r'# HELP|# TYPE ', None),
    ("Elasticsearch", "datastore", "body", r'"cluster_name"|"lucene_version"', None),
    ("Jenkins", "ci", "header:x-jenkins", r"([\d.]+)", 1),
    ("GitLab", "devops", "body", r'gitlab', None),
    ("Spring Boot", "framework", "body", r'"_links".*"self".*"href"', None),
    ("Swagger UI", "api-docs", "body", r'swagger-ui', None),
    ("GraphQL", "api", "body", r'graphql', None),
    ("phpMyAdmin", "admin-panel", "body", r'phpmyadmin', None),
    ("Sentry", "monitoring", "body", r'sentry-cdn|@sentry', None),
    ("reCAPTCHA", "security", "body", r'recaptcha', None),
    ("Cloudflare", "cdn", "header:server", r"cloudflare", None),
]

# Discovered endpoint paths that strongly imply a technology (second-source).
PATH_TECH = [
    (r"/wp-json|/wp-login\.php|/xmlrpc\.php", "WordPress", "cms"),
    (r"/_next/", "Next.js", "framework"),
    (r"/_nuxt/", "Nuxt.js", "framework"),
    (r"/actuator", "Spring Boot", "framework"),
    (r"/graphql", "GraphQL", "api"),
    (r"/swagger|/openapi|/api-docs", "Swagger/OpenAPI", "api-docs"),
    (r"/sites/default/|/core/misc/", "Drupal", "cms"),
    (r"/umbraco", "Umbraco", "cms"),
    (r"/typo3", "TYPO3", "cms"),
    (r"/phpmyadmin", "phpMyAdmin", "admin-panel"),
    (r"/\.git/", "Exposed .git", "exposure"),
    (r"/metrics", "Prometheus metrics", "monitoring"),
]

BANNER_HINTS = [
    (r"OpenSSH[_-]([\w.]+)", "OpenSSH"),
    (r"vsftpd ([\d.]+)", "vsftpd"),
    (r"ProFTPD ([\d.]+)", "ProFTPD"),
    (r"Postfix", "Postfix"),
    (r"Exim ([\d.]+)", "Exim"),
    (r"MySQL", "MySQL"),
    (r"MariaDB", "MariaDB"),
    (r"Redis", "Redis"),
    (r"MongoDB", "MongoDB"),
    (r"RabbitMQ", "RabbitMQ"),
    (r"Microsoft SQL Server", "MSSQL"),
    (r"PostgreSQL", "PostgreSQL"),
]

MAX_CRAWL_LINKS = 40
CONNECT_TIMEOUT = float(__import__("os").environ.get("ASM_CONNECT_TIMEOUT", "1.5"))
HTTP_TIMEOUT = float(__import__("os").environ.get("ASM_HTTP_TIMEOUT", "8.0"))
PORT_CONCURRENCY = int(__import__("os").environ.get("ASM_PORT_CONCURRENCY", "200"))

# --- noise control --------------------------------------------------------
# Default scan mode. "passive" touches the target's own hosts as little as
# possible (ideally one homepage GET) and sources ports/services/vulns from
# Shodan InternetDB instead of scanning. "light" adds a small, slow, throttled
# active layer. "aggressive" is the full active sweep (noisy — can get IPs
# blocked). Passive is the default precisely to avoid that.
DEFAULT_SCAN_MODE = (__import__("os").environ.get("ASM_SCAN_MODE", "passive") or "passive").lower()

# look-alike / typosquat detection (apex domains only). On by default but capped;
# set ASM_LOOKALIKE=0 to disable. Only DNS-validated (registered) hits are kept.
LOOKALIKE_ENABLED = __import__("os").environ.get("ASM_LOOKALIKE", "1") not in ("0", "false", "no")
LOOKALIKE_MAX = int(__import__("os").environ.get("ASM_LOOKALIKE_MAX", "800"))

# throttling for any ACTIVE requests against a target's hosts
ACTIVE_CONCURRENCY = int(__import__("os").environ.get("ASM_ACTIVE_CONCURRENCY", "8"))
ACTIVE_DELAY = float(__import__("os").environ.get("ASM_ACTIVE_DELAY", "0.15"))   # seconds between probes
ACTIVE_JITTER = float(__import__("os").environ.get("ASM_ACTIVE_JITTER", "0.25"))  # +random up to this

# a deliberately small port set for "light" mode (top services only)
LIGHT_PORTS = [21, 22, 25, 80, 110, 143, 443, 445, 3389, 8080, 8443]


def valid_mode(m: str | None) -> str:
    m = (m or "").lower()
    return m if m in ("passive", "light", "aggressive") else DEFAULT_SCAN_MODE



def get_ports() -> list[int]:
    import os
    raw = os.environ.get("ASM_PORTS")
    if not raw:
        return DEFAULT_PORTS
    try:
        return [int(p) for p in raw.split(",") if p.strip()]
    except ValueError:
        return DEFAULT_PORTS


# --- host resolution -------------------------------------------------------

def resolve(target: str) -> list[str]:
    """Return unique IPs for a domain, or the IP itself if already numeric."""
    host = target
    if "://" in host:
        host = urlparse(host).hostname or host
    try:
        socket.inet_aton(host)
        return [host]
    except OSError:
        pass
    ips: set[str] = set()
    try:
        for info in socket.getaddrinfo(host, None):
            ips.add(info[4][0])
    except socket.gaierror:
        pass
    return sorted(ips)


def is_ip(value: str) -> bool:
    """True if the value is an IPv4 or IPv6 address. Domain-only features
    (look-alikes, email auth, breach search) must skip anything this matches."""
    import ipaddress
    host = (urlparse(value).hostname or value) if "://" in value else value
    host = (host or "").strip().strip("[]")
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


# --- subdomain enumeration -------------------------------------------------

# Common subdomain labels for the self-contained DNS brute-force pass.
SUBDOMAIN_WORDLIST = [
    "www", "mail", "remote", "blog", "webmail", "server", "ns1", "ns2", "smtp",
    "secure", "vpn", "m", "shop", "ftp", "mail2", "test", "portal", "ns", "ww1",
    "host", "support", "dev", "web", "bbs", "mx", "email", "cloud", "1", "mail1",
    "2", "forum", "owa", "www2", "gw", "admin", "store", "mx1", "cdn", "api",
    "exchange", "app", "gov", "2tty", "vps", "govyty", "hgfgdf", "news", "1rer",
    "lists", "beta", "staging", "stage", "demo", "internal", "intranet", "extranet",
    "vpn2", "auth", "sso", "login", "dashboard", "grafana", "kibana", "jenkins",
    "gitlab", "git", "jira", "confluence", "wiki", "docs", "status", "monitor",
    "metrics", "prometheus", "db", "database", "mysql", "postgres", "redis",
    "mongo", "elastic", "search", "cache", "queue", "broker", "kafka", "rabbitmq",
    "backup", "backups", "old", "new", "legacy", "archive", "static", "assets",
    "cdn2", "img", "images", "media", "files", "download", "downloads", "upload",
    "uploads", "s3", "storage", "data", "reports", "analytics", "stats", "log",
    "logs", "syslog", "ns3", "ns4", "dns", "dns1", "dns2", "mx2", "mx3", "pop",
    "pop3", "imap", "relay", "mailgw", "autodiscover", "autoconfig", "cpanel",
    "whm", "webdisk", "proxy", "gateway", "router", "firewall", "vcenter", "esxi",
    "sip", "voip", "pbx", "chat", "video", "conference", "meet", "sandbox", "qa",
    "uat", "preprod", "prod", "production", "corp", "hr", "finance", "billing",
    "crm", "erp", "cms", "wordpress", "wp", "drupal", "shop2", "payment", "pay",
    "checkout", "customer", "clients", "client", "partner", "partners", "vendor",
    "mobile", "ios", "android", "apps", "service", "services", "microservice",
    "gateway2", "lb", "loadbalancer", "cluster", "node", "k8s", "kubernetes",
    "docker", "registry", "ci", "cd", "build", "deploy", "artifactory", "nexus",
]


async def crt_sh_subdomains(client: httpx.AsyncClient, domain: str) -> set[str]:
    """Passive discovery via Certificate Transparency logs (crt.sh).

    Best-effort: any network/parse error yields an empty set so the caller can
    fall back to the DNS brute-force.
    """
    found: set[str] = set()
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    try:
        r = await client.get(url, timeout=20.0)
        if r.status_code != 200:
            return found
        data = r.json()
    except (httpx.HTTPError, ValueError):
        return found
    for entry in data if isinstance(data, list) else []:
        for field in ("name_value", "common_name"):
            raw = str(entry.get(field, ""))
            for name in raw.splitlines():
                name = name.strip().lower().lstrip("*.")
                if name.endswith("." + domain) and name != domain and "@" not in name:
                    found.add(name)
    return found


def bruteforce_candidates(domain: str) -> set[str]:
    import os
    extra = os.environ.get("ASM_SUBDOMAIN_WORDLIST", "")
    words = list(SUBDOMAIN_WORDLIST)
    if extra:
        words += [w.strip() for w in extra.split(",") if w.strip()]
    return {f"{w}.{domain}" for w in words}


async def _verify_resolves(names: set[str], limit: int) -> list[dict]:
    """Keep only names that resolve; return [{host, ips}] up to `limit`."""
    sem = asyncio.Semaphore(50)
    results: list[dict] = []

    async def check(name: str) -> None:
        async with sem:
            ips = await asyncio.to_thread(resolve, name)
        if ips:
            results.append({"host": name, "ips": ips})

    await asyncio.gather(*[check(n) for n in names])
    results.sort(key=lambda r: r["host"])
    return results[:limit]


async def enumerate_subdomains(client: httpx.AsyncClient, domain: str,
                               limit: int | None = None,
                               active: bool = False) -> list[dict]:
    """Passive (crt.sh) subdomain discovery, plus optional active DNS
    brute-force when `active` is set. Results are DNS-verified.

    Note DNS brute-force only queries resolvers (not the target's web hosts), but
    it is still active traffic, so passive mode leaves it off.
    """
    import os
    if limit is None:
        limit = int(os.environ.get("ASM_MAX_SUBDOMAINS", "200"))
    domain = domain.lower().strip()
    if is_ip(domain) or "." not in domain:
        return []
    candidates = await crt_sh_subdomains(client, domain)     # passive
    if active:
        candidates |= bruteforce_candidates(domain)          # active DNS
    candidates.discard(domain)
    return await _verify_resolves(candidates, limit)


# --- look-alike / typosquat detection --------------------------------------
# Generate impersonation candidates (typos, homoglyphs, TLD swaps, etc.) then
# VALIDATE each by DNS so only registered/live look-alikes are reported — this
# validation is what keeps the feature from drowning you in false positives.

_KEYBOARD = {
    "q": "wa", "w": "qeas", "e": "wrsd", "r": "etdf", "t": "ryfg", "y": "tugh",
    "u": "yihj", "i": "uojk", "o": "ipkl", "p": "ol", "a": "qwsz", "s": "awedxz",
    "d": "serfcx", "f": "drtgvc", "g": "ftyhbv", "h": "gyujnb", "j": "huikmn",
    "k": "jiolm", "l": "kop", "z": "asx", "x": "zsdc", "c": "xdfv", "v": "cfgb",
    "b": "vghn", "n": "bhjm", "m": "njk",
}
_HOMOGLYPHS = {
    "a": ["4", "@", "à", "á", "â", "ã", "ä", "å"], "b": ["d", "lb", "ib"],
    "c": ["ç", "e"], "d": ["b", "cl", "dl"], "e": ["3", "é", "ê", "ë"],
    "g": ["q", "9", "6"], "i": ["1", "l", "!", "í", "ï"], "l": ["1", "i", "|"],
    "m": ["rn", "nn"], "n": ["m", "ñ"], "o": ["0", "ο", "ø", "ó", "ö"],
    "q": ["g", "9"], "s": ["5", "$", "z"], "t": ["7", "+"], "u": ["v", "ú", "ü"],
    "v": ["u", "vv"], "w": ["vv", "ww"], "z": ["2", "s"], "0": ["o"], "1": ["l", "i"],
}
_ALT_TLDS = ["com", "net", "org", "co", "io", "info", "biz", "online", "site",
             "xyz", "app", "dev", "us", "co.uk", "com.au", "in", "me", "cc", "shop",
             "store", "live", "email", "support", "cloud", "link"]
_ADD_WORDS = ["login", "secure", "account", "verify", "support", "portal", "mail",
              "auth", "signin", "web", "online"]
_TWO_LEVEL = {"co.uk", "com.au", "co.in", "co.nz", "co.za", "com.br", "co.jp",
              "com.sg", "org.uk", "gov.uk", "ac.uk", "com.mx"}


def split_registrable(domain: str) -> tuple[str, str]:
    """Split into (name, tld) handling common two-level TLDs. Best-effort."""
    domain = domain.lower().strip().strip(".")
    parts = domain.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in _TWO_LEVEL:
        return ".".join(parts[:-2]), ".".join(parts[-2:])
    if len(parts) >= 2:
        return ".".join(parts[:-1]), parts[-1]
    return domain, ""


def generate_lookalikes(domain: str, max_n: int = 800) -> set[str]:
    """Produce impersonation candidates for a domain (apex/registrable)."""
    # look-alikes are meaningless for IPs — only generate for real domain names
    if is_ip(domain) or "." not in domain:
        return set()
    name, tld = split_registrable(domain)
    # only permute the left-most label of the registrable name
    head = name.split(".")[0]
    rest = name[len(head):]  # "" or ".sub" — usually ""
    out: set[str] = set()

    def emit(new_head: str, new_tld: str = None):
        nh = new_head.strip(".-")
        if nh and nh != head:
            out.add(f"{nh}{rest}.{new_tld or tld}")
        elif new_tld and new_tld != tld:
            out.add(f"{head}{rest}.{new_tld}")

    n = len(head)
    # omission
    for i in range(n):
        emit(head[:i] + head[i+1:])
    # repetition
    for i in range(n):
        emit(head[:i] + head[i] + head[i:])
    # transposition (swap adjacent)
    for i in range(n - 1):
        emit(head[:i] + head[i+1] + head[i] + head[i+2:])
    # keyboard replacement + insertion
    for i, ch in enumerate(head):
        for k in _KEYBOARD.get(ch, ""):
            emit(head[:i] + k + head[i+1:])          # replace
            emit(head[:i] + k + head[i:])            # insert
    # homoglyph substitutions
    for i, ch in enumerate(head):
        for g in _HOMOGLYPHS.get(ch, []):
            emit(head[:i] + g + head[i+1:])
    # hyphenation
    for i in range(1, n):
        emit(head[:i] + "-" + head[i:])
    # vowel swaps
    vowels = "aeiou"
    for i, ch in enumerate(head):
        if ch in vowels:
            for v in vowels:
                if v != ch:
                    emit(head[:i] + v + head[i+1:])
    # TLD swaps (same name, different TLD)
    for t in _ALT_TLDS:
        emit(head, t)
    # additions (prefix / suffix words, hyphenated)
    for w in _ADD_WORDS:
        emit(f"{head}-{w}")
        emit(f"{w}-{head}")
    emit(head + "s"); emit(head + "-inc"); emit(head + "-llc")

    out.discard(domain)
    # punycode-encode any IDN (unicode homoglyph) candidates so they're resolvable
    encoded = set()
    for d in out:
        try:
            encoded.add(d.encode("idna").decode("ascii"))
        except (UnicodeError, ValueError):
            if all(ord(c) < 128 for c in d):
                encoded.add(d)
    return set(list(encoded)[:max_n])


def _resolve_lookalike(domain: str) -> dict:
    """One look-alike's DNS footprint: A records, MX presence, NS (registered)."""
    import dns.resolver as _r
    res = {"a": [], "mx": False, "ns": []}
    resolver = _r.Resolver()
    resolver.lifetime = 2.0
    resolver.timeout = 2.0
    try:
        res["a"] = [x.address for x in resolver.resolve(domain, "A")]
    except Exception:
        pass
    try:
        res["ns"] = [str(x.target).rstrip(".") for x in resolver.resolve(domain, "NS")]
    except Exception:
        pass
    try:
        resolver.resolve(domain, "MX"); res["mx"] = True
    except Exception:
        pass
    return res


async def _probe_lookalike_http(client: httpx.AsyncClient, domain: str) -> dict:
    """Is the look-alike actually serving a website? (a live site is a strong
    'this is weaponised' signal). Returns liveness, status, scheme, title."""
    for scheme in ("https", "http"):
        try:
            r = await client.get(f"{scheme}://{domain}", timeout=HTTP_TIMEOUT)
        except httpx.HTTPError:
            continue
        title = ""
        tm = re.search(r"<title[^>]*>(.*?)</title>", r.text[:20000], re.I | re.S)
        if tm:
            title = tm.group(1).strip()[:120]
        return {"live": True, "status": r.status_code, "scheme": scheme, "title": title}
    return {"live": False, "status": None, "scheme": None, "title": ""}


async def find_lookalikes(client: httpx.AsyncClient, domain: str, legit_ips: list[str],
                          max_candidates: int = 1200, technique_of=None) -> list[dict]:
    """Generate + DNS-validate look-alikes. Only registered/resolving domains are
    returned (unregistered permutations are discarded — the false-positive guard).
    Each resolving hit is HTTP-probed; a live site OR email (MX) makes it High risk.
    """
    if is_ip(domain):
        return []
    candidates = generate_lookalikes(domain, max_candidates)
    legit = set(legit_ips or [])
    sem = asyncio.Semaphore(120)
    results: list[dict] = []

    async def check(cand: str) -> None:
        async with sem:
            dns_info = await asyncio.to_thread(_resolve_lookalike, cand)
        registered = bool(dns_info["a"] or dns_info["ns"])
        if not registered:
            return                          # <-- discards the vast majority (noise)
        ips = dns_info["a"]
        same_owner = bool(ips) and set(ips).issubset(legit)
        # probe HTTP only when it resolves (parked NS-only domains serve nothing)
        http = await _probe_lookalike_http(client, cand) if ips else \
            {"live": False, "status": None, "scheme": None, "title": ""}
        mx = dns_info["mx"]
        # risk: a resolving look-alike that either serves a live site OR can send
        # mail (MX) is weaponisable → High. Registered-but-inert → medium/low.
        if same_owner:
            risk = "owned"                  # likely a defensive registration of yours
        elif ips and (http["live"] or mx):
            risk = "high"
        elif ips:
            risk = "medium"                  # resolves but no site and no mail yet
        else:
            risk = "low"                     # registered but parked (NS only)
        results.append({
            "domain": cand, "ips": ips, "mx": mx,
            "http_live": http["live"], "http_status": http["status"],
            "http_title": http["title"],
            "ns": dns_info["ns"][:4], "registered": True,
            "resolves": bool(ips), "same_owner": same_owner, "risk": risk,
        })

    await asyncio.gather(*[check(c) for c in candidates])
    order = {"high": 0, "medium": 1, "low": 2, "owned": 3}
    results.sort(key=lambda r: (order.get(r["risk"], 9), r["domain"]))
    return results


# --- Brand impersonation detection -----------------------------------------
# Catches impersonation that look-alikes miss: domains that DON'T resemble
# yours but host your brand name, logo, favicon, or images (phishing/clones).
# Strategy: find candidates by brand term (Certificate Transparency) and by
# copied favicon (Shodan, opt-in), then VERIFY each by content so only sites
# actually showing your brand are reported — keeping false positives low.

BRAND_ENABLED = __import__("os").environ.get("ASM_BRAND_MONITOR", "1") not in ("0", "false", "no")
BRAND_MAX = int(__import__("os").environ.get("ASM_BRAND_MAX", "40"))


def _brand_term(domain: str) -> str:
    name, _ = split_registrable(domain)
    return name.split(".")[0].lower()


def _registrable_domain(d: str) -> str:
    name, tld = split_registrable(d)
    reg = name.split(".")[-1]
    return f"{reg}.{tld}" if tld else d


async def _fetch_favicon(client: httpx.AsyncClient, base: str):
    """Return (md5, mmh3_shodan_hash, raw_bytes) for a site's favicon, or Nones."""
    import hashlib
    urls: list[str] = []
    try:
        r = await client.get(base, timeout=HTTP_TIMEOUT)
        for m in re.finditer(r'<link[^>]+rel=["\'][^"\']*icon[^"\']*["\'][^>]*>',
                             r.text[:120000], re.I):
            hm = re.search(r'href=["\']([^"\']+)["\']', m.group(0))
            if hm:
                urls.append(urljoin(base, hm.group(1)))
    except (httpx.HTTPError, ValueError):
        pass
    urls.append(urljoin(base, "/favicon.ico"))
    for u in urls[:3]:
        try:
            fr = await client.get(u, timeout=HTTP_TIMEOUT)
            if fr.status_code == 200 and fr.content and len(fr.content) > 60:
                data = fr.content
                md5 = hashlib.md5(data).hexdigest()
                mmh = None
                try:
                    import mmh3, base64
                    mmh = mmh3.hash(base64.encodebytes(data))
                except Exception:
                    pass
                return md5, mmh, data
        except (httpx.HTTPError, ValueError):
            continue
    return None, None, None


async def _brand_ct_candidates(client: httpx.AsyncClient, term: str) -> set[str]:
    """Domains seen in Certificate Transparency logs containing the brand term."""
    cands: set[str] = set()
    try:
        r = await client.get(f"https://crt.sh/?q=%25{term}%25&output=json",
                             timeout=25.0)
        if r.status_code == 200:
            for row in r.json():
                for nm in str(row.get("name_value", "")).split("\n"):
                    nm = nm.strip().lower().lstrip("*.")
                    if nm and term in nm and not is_ip(nm) and "." in nm:
                        cands.add(nm)
    except (httpx.HTTPError, ValueError):
        pass
    return cands


async def _shodan_favicon_candidates(client: httpx.AsyncClient, mmh_hash: int) -> set[str]:
    """Hosts anywhere serving the same favicon (copied logo) — needs Shodan key."""
    key = _env("ASM_SHODAN_API_KEY")
    if not key or mmh_hash is None:
        return set()
    hosts: set[str] = set()
    try:
        r = await client.get("https://api.shodan.io/shodan/host/search",
                             params={"key": key, "query": f"http.favicon.hash:{mmh_hash}"},
                             timeout=20.0)
        if r.status_code == 200:
            for m in r.json().get("matches", []):
                for hn in (m.get("hostnames") or []):
                    if hn and not is_ip(hn):
                        hosts.add(hn.lower())
                dom = m.get("domains") or []
                for d in dom:
                    hosts.add(str(d).lower())
    except (httpx.HTTPError, ValueError):
        pass
    return hosts


async def find_brand_impersonations(client: httpx.AsyncClient, domain: str,
                                    max_candidates: int = 40) -> list[dict]:
    """Find external sites impersonating the brand (name/logo/favicon/images)."""
    if is_ip(domain):
        return []
    term = _brand_term(domain)
    if len(term) < 4:               # too short/generic → skip (avoids noise)
        return []

    legit_md5, legit_mmh, _ = await _fetch_favicon(client, f"https://{domain}")

    cands = await _brand_ct_candidates(client, term)
    cands |= await _shodan_favicon_candidates(client, legit_mmh)
    # drop anything we own (the apex or its subdomains)
    cands = {c for c in cands
             if not (c == domain or c.endswith("." + domain))}
    # collapse to one hostname per registrable domain, then cap
    by_reg: dict[str, str] = {}
    for c in cands:
        by_reg.setdefault(_registrable_domain(c), c)
    targets = list(by_reg.values())[:max_candidates]

    sem = asyncio.Semaphore(20)
    out: list[dict] = []

    async def verify(cand: str) -> None:
        async with sem:
            ips = await asyncio.to_thread(resolve, cand)
            if not ips:
                return                       # not live → skip
            fav_md5, _, _ = await _fetch_favicon(client, f"https://{cand}")
            favicon_match = bool(legit_md5 and fav_md5 and fav_md5 == legit_md5)
            title, login, hotlink, brand_in_title = "", False, False, False
            try:
                r = await client.get(f"https://{cand}", timeout=HTTP_TIMEOUT)
                body = r.text[:150000]
                tm = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
                title = (tm.group(1).strip()[:140] if tm else "")
                brand_in_title = term in title.lower()
                login = bool(re.search(r'type=["\']password["\']', body, re.I))
                hotlink = domain in body      # references YOUR domain's assets/links
            except (httpx.HTTPError, ValueError):
                pass

            evidence = []
            if favicon_match:
                evidence.append("copied favicon/logo")
            if brand_in_title:
                evidence.append("brand name in page title")
            if hotlink:
                evidence.append("hotlinks your domain's assets")
            if login:
                evidence.append("credential login form")
            if not evidence:
                return                       # no brand signal → not impersonation

            if favicon_match or hotlink or (brand_in_title and login):
                risk = "high"
            elif brand_in_title:
                risk = "medium"
            else:
                risk = "low"
            out.append({"domain": cand, "ips": ips, "title": title,
                        "favicon_match": favicon_match, "brand_in_title": brand_in_title,
                        "hotlinks_legit": hotlink, "login_form": login,
                        "risk": risk, "evidence": evidence, "source": "brand-monitor"})

    await asyncio.gather(*[verify(c) for c in targets])
    order = {"high": 0, "medium": 1, "low": 2}
    out.sort(key=lambda r: (order.get(r["risk"], 9), r["domain"]))
    return out


# --- DNS records & name servers --------------------------------------------

try:
    import dns.resolver as _dnsresolver
    _HAS_DNS = True
except ImportError:                        # tool still runs without dnspython
    _HAS_DNS = False

DNS_RECORD_TYPES = ("A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA")


def dns_records(domain: str) -> dict[str, list[str]]:
    """Fetch common DNS record types. Returns {type: [values]}."""
    out: dict[str, list[str]] = {}
    if not _HAS_DNS or is_ip(domain):
        return out
    resolver = _dnsresolver.Resolver()
    resolver.lifetime = 6.0
    resolver.timeout = 3.0
    for rtype in DNS_RECORD_TYPES:
        try:
            ans = resolver.resolve(domain, rtype)
            out[rtype] = sorted({r.to_text().strip() for r in ans})
        except Exception:
            continue
    return out


# --- WAF / CDN fingerprinting ----------------------------------------------

# (name, source, key, regex). source: header | cookie | cname
WAF_SIGNATURES = [
    ("Cloudflare", "header", "server", r"cloudflare"),
    ("Cloudflare", "header", "cf-ray", r".+"),
    ("Akamai", "header", "server", r"akamaighost"),
    ("Akamai", "header", "x-akamai-transformed", r".+"),
    ("AWS CloudFront", "header", "x-amz-cf-id", r".+"),
    ("AWS CloudFront", "header", "via", r"cloudfront"),
    ("AWS WAF", "header", "x-amzn-waf-action", r".+"),
    ("Imperva Incapsula", "header", "x-iinfo", r".+"),
    ("Imperva Incapsula", "cookie", "visid_incap", r".+"),
    ("Imperva Incapsula", "cookie", "incap_ses", r".+"),
    ("Sucuri CloudProxy", "header", "server", r"sucuri"),
    ("Sucuri CloudProxy", "header", "x-sucuri-id", r".+"),
    ("F5 BIG-IP", "cookie", "bigipserver", r".+"),
    ("F5 BIG-IP ASM", "header", "x-waf-event-info", r".+"),
    ("Barracuda", "cookie", "barra_counter_session", r".+"),
    ("Fastly", "header", "x-served-by", r"cache-"),
    ("Fastly", "header", "fastly-debug-digest", r".+"),
    ("Azure Front Door / WAF", "header", "x-azure-ref", r".+"),
    ("Azure Front Door", "header", "x-fd-int-roxy-purgeid", r".+"),
    ("Wordfence", "body", "", r"wordfence"),
    ("ModSecurity", "header", "server", r"mod_security|modsecurity"),
    ("DDoS-Guard", "header", "server", r"ddos-guard"),
    ("StackPath", "header", "server", r"stackpath"),
    ("Cloudflare", "cookie", "__cfduid", r".+"),
    ("Cloudflare", "cookie", "__cf_bm", r".+"),
]

CNAME_PROVIDERS = [
    (r"\.cloudflare\.net", "Cloudflare"),
    (r"\.akamaiedge\.net|\.akamai\.net|\.edgekey\.net", "Akamai"),
    (r"\.incapdns\.net", "Imperva Incapsula"),
    (r"\.cloudfront\.net", "AWS CloudFront"),
    (r"\.azureedge\.net|\.azurefd\.net", "Azure Front Door"),
    (r"\.fastly\.net", "Fastly"),
    (r"\.sucuri\.net", "Sucuri CloudProxy"),
]


def _waf_from_cname(dns_recs: dict) -> list[dict]:
    found = []
    cnames = " ".join(dns_recs.get("CNAME", []))
    for pat, name in CNAME_PROVIDERS:
        if re.search(pat, cnames, re.I):
            found.append({"name": name, "evidence": "CNAME"})
    return found


async def detect_waf(client: httpx.AsyncClient, domain: str,
                     dns_recs: dict, active_probe: bool = False) -> list[dict]:
    """Identify a fronting WAF/CDN.

    Passive: response headers, cookies, and CNAME chains.
    Active:  send a benign but WAF-triggering probe and compare against a clean
             baseline — a block response (403/406/429/501/999 or a known block
             page) that only appears on the triggered request signals an active
             WAF even when it hides its headers.
    """
    found: dict[str, dict] = {}
    for w in _waf_from_cname(dns_recs):
        found[w["name"]] = w

    scheme = "https"
    try:
        base = await client.get(f"{scheme}://{domain}", timeout=HTTP_TIMEOUT)
    except httpx.HTTPError:
        try:
            base = await client.get(f"http://{domain}", timeout=HTTP_TIMEOUT)
            scheme = "http"
        except httpx.HTTPError:
            return list(found.values())

    headers = {k.lower(): v for k, v in base.headers.items()}
    cookies = " ".join(base.headers.get_list("set-cookie")).lower() if hasattr(base.headers, "get_list") else headers.get("set-cookie", "").lower()
    body = base.text[:60_000].lower()

    for name, source, key, pat in WAF_SIGNATURES:
        hay = ""
        if source == "header":
            hay = headers.get(key, "")
        elif source == "cookie":
            hay = cookies
            if key and key.lower() not in cookies:
                continue
        elif source == "body":
            hay = body
        if hay and re.search(pat, hay, re.I):
            found.setdefault(name, {"name": name, "evidence": source})

    # --- active probe (benign trigger vs baseline) ---
    if not active_probe:
        return list(found.values())
    trigger = ("/?wafcheck=%3Cscript%3Ealert(1)%3C%2Fscript%3E"
               "&q=1%20OR%201%3D1--&path=../../etc/passwd")
    try:
        probe = await client.get(f"{scheme}://{domain}{trigger}", timeout=HTTP_TIMEOUT)
        block_codes = {403, 406, 429, 501, 999}
        pbody = probe.text[:8000].lower()
        block_markers = ("access denied", "request blocked", "web application firewall",
                         "blocked by", "attention required", "malicious", "forbidden",
                         "406 not acceptable", "your request has been blocked",
                         "incident id", "support id")
        triggered = (
            (probe.status_code in block_codes and base.status_code not in block_codes)
            or any(mk in pbody for mk in block_markers)
        )
        if triggered:
            # try to attribute; else record a generic active-WAF finding
            attributed = False
            phe = {k.lower(): v for k, v in probe.headers.items()}
            for name, source, key, pat in WAF_SIGNATURES:
                if source == "header" and re.search(pat, phe.get(key, ""), re.I):
                    found.setdefault(name, {"name": name, "evidence": "active-probe"})
                    attributed = True
            if not attributed and not found:
                found["Active WAF (unidentified)"] = {
                    "name": "Active WAF (unidentified)", "evidence": "active-probe",
                    "block_status": probe.status_code}
    except httpx.HTTPError:
        pass
    return list(found.values())


# --- Identity provider: Azure AD / ADFS / M365 -----------------------------

async def detect_idp(client: httpx.AsyncClient, domain: str,
                     dns_recs: dict) -> list[dict]:
    """Detect Microsoft 365 / Azure AD (Managed) vs ADFS (Federated), plus
    other identity signals. Uses Microsoft's public realm endpoint."""
    found: list[dict] = []

    # 1) Microsoft user-realm endpoint: Managed => Azure AD, Federated => ADFS
    url = (f"https://login.microsoftonline.com/getuserrealm.srf"
           f"?login=user@{domain}&xml=1")
    try:
        r = await client.get(url, timeout=HTTP_TIMEOUT)
        text = r.text
        ns = re.search(r"<NameSpaceType>(\w+)</NameSpaceType>", text)
        if ns:
            kind = ns.group(1)
            if kind == "Managed":
                found.append({"provider": "Microsoft 365 / Azure AD",
                              "mode": "Managed (cloud)", "evidence": "MS realm"})
            elif kind == "Federated":
                auth = re.search(r"<AuthURL>(.*?)</AuthURL>", text)
                fed = re.search(r"<FederationBrandName>(.*?)</FederationBrandName>", text)
                d = {"provider": "ADFS (federated to Azure AD)",
                     "mode": "Federated", "evidence": "MS realm"}
                if auth:
                    d["auth_url"] = auth.group(1)
                    fh = urlparse(auth.group(1)).hostname
                    if fh:
                        d["federation_host"] = fh.lower()   # e.g. adfs.contoso.com
                if fed:
                    d["brand"] = fed.group(1)
                found.append(d)
    except (httpx.HTTPError, ValueError):
        pass

    # 2) DNS-based Microsoft signals
    mx = " ".join(dns_recs.get("MX", [])).lower()
    txt = " ".join(dns_recs.get("TXT", [])).lower()
    if "mail.protection.outlook.com" in mx and not any("365" in f["provider"] for f in found):
        found.append({"provider": "Microsoft 365 (Exchange Online)",
                      "mode": "MX", "evidence": "MX -> outlook.com"})
    if "ms=" in txt:
        found.append({"provider": "Microsoft domain verification",
                      "mode": "TXT", "evidence": "TXT MS="})
    if "google-site-verification" in txt or "aspmx.l.google.com" in mx:
        found.append({"provider": "Google Workspace", "mode": "DNS",
                      "evidence": "Google MX/TXT"})

    # 3) common federation hostnames
    for label, tag in (("adfs", "ADFS endpoint"), ("sts", "STS endpoint"),
                       ("fs", "Federation Service")):
        host = f"{label}.{domain}"
        if await asyncio.to_thread(resolve, host):
            found.append({"provider": tag, "mode": "hostname",
                          "evidence": host, "host": host})
    return found


# --- Email security posture: SPF / DKIM / DMARC / DNSSEC / MTA-STS ----------

def email_security(domain: str) -> list[dict]:
    """Passive email-auth posture from DNS. Flags spoofable configurations."""
    if is_ip(domain):
        return []
    import dns.resolver as _r
    resolver = _r.Resolver()
    resolver.lifetime = 4.0
    resolver.timeout = 4.0

    def txt(name: str) -> list[str]:
        try:
            out = []
            for rr in resolver.resolve(name, "TXT"):
                try:
                    out.append(b"".join(rr.strings).decode("utf-8", "ignore"))
                except Exception:
                    out.append(str(rr).strip('"'))
            return out
        except Exception:
            return []

    findings: list[dict] = []

    spf = [t for t in txt(domain) if t.lower().startswith("v=spf1")]
    if spf:
        s = spf[0]; compact = s.replace(" ", "")
        if "+all" in compact:
            findings.append({"kind": "SPF", "status": "weak", "risk": "medium",
                             "policy": s[:150], "note": "+all is permissive — anyone may send as you"})
        elif "-all" in compact:
            findings.append({"kind": "SPF", "status": "present", "risk": "ok",
                             "policy": s[:150], "note": "hard-fail (-all) enforced"})
        else:
            findings.append({"kind": "SPF", "status": "present", "risk": "low",
                             "policy": s[:150], "note": "soft-fail (~all) — not strictly enforced"})
    else:
        findings.append({"kind": "SPF", "status": "missing", "risk": "medium",
                         "note": "no SPF record — easier to spoof mail from this domain"})

    dmarc = [t for t in txt("_dmarc." + domain) if t.lower().startswith("v=dmarc1")]
    if dmarc:
        d = dmarc[0].lower().replace(" ", "")
        m = re.search(r"p=(\w+)", d); pol = m.group(1) if m else "none"
        if pol == "none":
            findings.append({"kind": "DMARC", "status": "monitor", "risk": "medium",
                             "policy": "p=none", "note": "p=none — reports only, spoofed mail still delivered"})
        else:
            findings.append({"kind": "DMARC", "status": "enforced", "risk": "ok",
                             "policy": f"p={pol}", "note": f"enforced ({pol})"})
    else:
        findings.append({"kind": "DMARC", "status": "missing", "risk": "high",
                         "note": "no DMARC — spoofed mail is not rejected"})

    selectors = ["default", "google", "selector1", "selector2", "k1", "s1", "s2",
                 "mail", "dkim", "smtp", "mandrill", "zoho", "sendgrid", "mailjet", "mx"]
    found_sel = [sel for sel in selectors if txt(f"{sel}._domainkey.{domain}")]
    if found_sel:
        findings.append({"kind": "DKIM", "status": "present", "risk": "ok",
                         "note": "selector(s): " + ", ".join(found_sel)})

    try:
        resolver.resolve(domain, "DNSKEY"); dnssec = True
    except Exception:
        dnssec = False
    findings.append({"kind": "DNSSEC", "status": "enabled" if dnssec else "disabled",
                     "risk": "ok" if dnssec else "low",
                     "note": "DNSSEC enabled" if dnssec else "DNSSEC not enabled"})

    if txt("_mta-sts." + domain):
        findings.append({"kind": "MTA-STS", "status": "present", "risk": "ok",
                         "note": "MTA-STS policy published"})
    return findings


# --- Subdomain takeover detection (fingerprint-verified, low false-positive) -

_TAKEOVER_FINGERPRINTS = [
    ("github.io", "there isn't a github pages site here", "GitHub Pages"),
    ("herokudns.com", "no such app", "Heroku"),
    ("herokuapp.com", "no such app", "Heroku"),
    ("s3.amazonaws.com", "nosuchbucket", "AWS S3"),
    ("s3-website", "nosuchbucket", "AWS S3"),
    ("amazonaws.com", "the specified bucket does not exist", "AWS S3"),
    ("azurewebsites.net", "404 web site not found", "Azure App Service"),
    ("cloudapp.azure.com", "404 web site not found", "Azure Cloud"),
    ("trafficmanager.net", "404 web site not found", "Azure Traffic Manager"),
    ("blob.core.windows.net", "the specified blob does not exist", "Azure Blob"),
    ("fastly.net", "fastly error: unknown domain", "Fastly"),
    ("myshopify.com", "sorry, this shop is currently unavailable", "Shopify"),
    ("surge.sh", "project not found", "Surge.sh"),
    ("bitbucket.io", "repository not found", "Bitbucket"),
    ("ghost.io", "domain error", "Ghost"),
    ("pantheonsite.io", "the gods are wise, but do not know of the site", "Pantheon"),
    ("readthedocs.io", "unknown to read the docs", "Read the Docs"),
    ("wpengine.com", "the site you were looking for couldn't be found", "WP Engine"),
    ("unbouncepages.com", "the requested url was not found on this server", "Unbounce"),
    ("helpscoutdocs.com", "no settings were found for this company", "Help Scout"),
]


async def check_takeover(client: httpx.AsyncClient, domain: str,
                         cnames: list[str]) -> dict | None:
    """Flag a dangling CNAME only when the target service returns its
    unclaimed-resource fingerprint (verified, not just 'points at a service')."""
    for cname in cnames:
        cl = cname.lower().rstrip(".")
        for marker, fp, svc in _TAKEOVER_FINGERPRINTS:
            if marker not in cl:
                continue
            for scheme in ("https", "http"):
                try:
                    r = await client.get(f"{scheme}://{domain}", timeout=HTTP_TIMEOUT)
                except httpx.HTTPError:
                    continue
                if fp in r.text[:30000].lower():
                    return {"domain": domain, "service": svc, "cname": cl,
                            "fingerprint": fp, "risk": "high", "confirmed": True}
                break
    return None


# --- Public cloud storage exposure -----------------------------------------

BUCKET_SUFFIXES = [
    "", "-assets", "-static", "-media", "-backup", "-backups", "-data", "-prod",
    "-production", "-dev", "-development", "-staging", "-stage", "-test", "-qa",
    "-uploads", "-files", "-public", "-private", "-logs", "-log", "-archive",
    "-cdn", "-images", "-img", "-web", "-www", "-app", "-api", "-storage",
    "-store", "-content", "-download", "-downloads", "-config", "-secrets",
]


def bucket_candidates(domain: str) -> list[str]:
    import os
    label = domain.split(".")[0]
    bases = {label, domain.replace(".", "-"), domain.replace(".", "")}
    extra = os.environ.get("ASM_BUCKET_NAMES", "")
    if extra:
        bases |= {b.strip() for b in extra.split(",") if b.strip()}
    names: set[str] = set()
    for b in bases:
        for s in BUCKET_SUFFIXES:
            names.add(f"{b}{s}")
    return sorted(names)


async def _check_one_bucket(client: httpx.AsyncClient, name: str,
                            sem: asyncio.Semaphore) -> list[dict]:
    hits = []
    probes = [
        ("AWS S3", f"https://{name}.s3.amazonaws.com/"),
        ("Azure Blob", f"https://{name}.blob.core.windows.net/?comp=list"),
        ("Google Cloud Storage", f"https://storage.googleapis.com/{name}/"),
    ]
    async with sem:
        for provider, url in probes:
            try:
                r = await client.get(url, timeout=HTTP_TIMEOUT)
            except httpx.HTTPError:
                continue
            sc = r.status_code
            body = r.text[:2000]
            exists, public = False, False
            if provider == "AWS S3":
                if sc == 200:
                    exists, public = True, True
                elif sc == 403 and "AccessDenied" in body:
                    exists = True
            elif provider == "Azure Blob":
                if sc == 200 and "<EnumerationResults" in body:
                    exists, public = True, True
                elif sc in (403, 409) and "AuthenticationFailed" not in body:
                    exists = True
            else:  # GCS
                if sc == 200:
                    exists, public = True, True
                elif sc == 403 and "AccessDenied" in body:
                    exists = True
            if exists:
                hits.append({"provider": provider, "name": name, "url": url,
                             "public": public, "status": sc})
    return hits


async def find_exposed_buckets(client: httpx.AsyncClient, domain: str) -> list[dict]:
    if is_ip(domain):
        return []
    sem = asyncio.Semaphore(15)
    names = bucket_candidates(domain)
    results = await asyncio.gather(*[_check_one_bucket(client, n, sem) for n in names])
    return [h for sub in results for h in sub]


# --- passive intelligence: VirusTotal, Wayback Machine, breach exposure ------

def _env(key: str) -> str:
    import os
    return os.environ.get(key, "").strip()


async def virustotal_domain(client: httpx.AsyncClient, domain: str) -> dict:
    """Passive VirusTotal domain intel (needs ASM_VT_API_KEY).

    Queries the domain report plus four relationships:
      /subdomains          - subdomains VT has seen
      /urls                - URLs VT has crawled or had submitted
      /resolutions         - passive DNS / IP history
      /related_references  - related URLs and references
    Best-effort; missing key or any error yields an empty result.
    """
    out = {"reputation": None, "categories": {}, "subdomains": [], "urls": [],
           "resolutions": [], "references": []}
    key = _env("ASM_VT_API_KEY")
    if not key or is_ip(domain):
        return out
    headers = {"x-apikey": key}
    base = f"https://www.virustotal.com/api/v3/domains/{domain}"

    async def _get(url: str):
        try:
            r = await client.get(url, headers=headers, timeout=HTTP_TIMEOUT)
            return r.json() if r.status_code == 200 else None
        except (httpx.HTTPError, ValueError):
            return None

    report = await _get(base)
    if report:
        attr = report.get("data", {}).get("attributes", {})
        stats = attr.get("last_analysis_stats", {})
        out["reputation"] = {"malicious": stats.get("malicious", 0),
                             "suspicious": stats.get("suspicious", 0),
                             "harmless": stats.get("harmless", 0)}
        out["categories"] = attr.get("categories", {}) or {}

    # resolutions (passive DNS / IP history) fetched early: on the free tier the
    # per-minute limit can starve later calls, and this powers DNS history.
    res = await _get(base + "/resolutions?limit=40")
    if res:
        for item in res.get("data", []):
            a = item.get("attributes", {})
            ip = a.get("ip_address")
            if ip:
                ts = a.get("date")
                out["resolutions"].append({
                    "ip": ip,
                    "date": _epoch_to_date(ts),
                    "resolver": a.get("resolver", ""),
                })

    subs = await _get(base + "/subdomains?limit=40")
    if subs:
        for item in subs.get("data", []):
            sid = item.get("id")
            if sid and sid.endswith("." + domain):
                out["subdomains"].append(sid.lower())

    urls = await _get(base + "/urls?limit=40")
    if urls:
        for item in urls.get("data", []):
            a = item.get("attributes", {})
            u = a.get("url")
            if u:
                out["urls"].append({"url": u, "status": a.get("last_http_response_code")})

    refs = await _get(base + "/related_references?limit=20")
    if refs:
        for item in refs.get("data", []):
            a = item.get("attributes", {})
            u = a.get("url") or item.get("id")
            if u:
                out["references"].append({"url": u, "title": a.get("title", "")})
    return out


def _epoch_to_date(ts) -> str:
    try:
        from datetime import datetime, timezone
        return datetime.fromtimestamp(int(ts), timezone.utc).strftime("%Y-%m-%d")
    except (ValueError, TypeError, OSError):
        return ""


async def _cdx(client: httpx.AsyncClient, domain: str, fields: str,
               extra: str = "", limit: int = 200) -> list[list]:
    url = ("http://web.archive.org/cdx/search/cdx"
           f"?url=*.{domain}/*&output=json&fl={fields}&collapse=urlkey"
           f"&limit={limit}{extra}")
    try:
        r = await client.get(url, timeout=25.0)
        if r.status_code != 200:
            return []
        rows = r.json()
    except (httpx.HTTPError, ValueError):
        return []
    if rows and isinstance(rows[0], list) and rows[0] and rows[0][0] in ("original", "timestamp"):
        rows = rows[1:]
    return rows


async def wayback_urls(client: httpx.AsyncClient, domain: str,
                       limit: int = 200) -> list[str]:
    """Historical URLs for a domain from the Wayback Machine CDX API (no key)."""
    if is_ip(domain):
        return []
    rows = await _cdx(client, domain, "original", limit=limit)
    seen, out = set(), []
    for row in rows:
        u = row[0] if isinstance(row, list) else row
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    return out[:limit]


# regexes for pulling endpoints out of JavaScript
_JS_PATH_RE = re.compile(r"""["'`](/[A-Za-z0-9_\-./]{1,}(?:\?[^"'`\s]{0,120})?)["'`]""")
_JS_FULLURL_RE = re.compile(r"""https?://[A-Za-z0-9.\-]+/[A-Za-z0-9_\-./]{1,}""")

# file types that are static assets, not application endpoints
_ASSET_EXT = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".avif", ".ico",
              ".css", ".woff", ".woff2", ".ttf", ".eot", ".otf", ".map", ".mp4",
              ".webm", ".mp3", ".wav", ".m4a", ".ogg", ".bmp", ".cur")
# tokens that betray a regex / format-string / MIME type wrongly captured as a path
_JS_JUNK = ("//", "\\", "${", "{{", "}}", "*", "|", "^", "$", "(", ")", "[", "]",
            "<", ">", " ", "\t")
# common MIME subtypes and regex flags that leak in as bogus "/x" paths
_JS_STOP = {"/json", "/xml", "/html", "/plain", "/javascript", "/css", "/text",
            "/octet-stream", "/g", "/i", "/m", "/gi", "/ig", "/s", "/u", "/y",
            "/n", "/r", "/t", "/0", "/1", "/api", "/"}


def _is_asset(url: str) -> bool:
    path = url.split("?")[0].split("#")[0].lower()
    return any(path.endswith(ext) for ext in _ASSET_EXT)


def _plausible_path(path: str) -> bool:
    """Heuristic: does this look like a real request path rather than a regex,
    format string, MIME type, or minified-code fragment?"""
    p = path.split("#")[0]
    core = p.split("?")[0]
    if len(core) < 2 or len(p) > 160:
        return False
    if p.lower() in _JS_STOP or core.lower() in _JS_STOP:
        return False
    if any(tok in p for tok in _JS_JUNK):
        return False
    # must contain at least one letter somewhere in the path portion
    if not any(c.isalpha() for c in core):
        return False
    # route templates (/users/:id, /v1/{id}) aren't fetchable URLs — drop as noise
    if ":" in core or "{" in core:
        return False
    # reject "paths" that are really decimal/version tokens like /1.2.3
    segs = [s for s in core.split("/") if s]
    if segs and all(re.fullmatch(r"[0-9.]+", s) for s in segs):
        return False
    return True


def _norm_endpoint(url: str) -> str:
    """Normalise for dedupe: drop fragment, collapse trailing slash."""
    u = url.split("#")[0]
    if u.endswith("/") and len(u.rstrip("/")) > len("https://x"):
        u = u.rstrip("/")
    return u


def _extract_endpoints_from_js(text: str, domain: str) -> set[str]:
    found: set[str] = set()
    for m in _JS_PATH_RE.findall(text):
        if _is_asset(m) or not _plausible_path(m):
            continue
        found.add(_norm_endpoint(m))
    for m in _JS_FULLURL_RE.findall(text):
        if domain in m and not _is_asset(m):
            path = "/" + m.split("/", 3)[3] if m.count("/") >= 3 else "/"
            if _plausible_path(path):
                found.add(_norm_endpoint(m))
    return found


async def wayback_deep_scan(client: httpx.AsyncClient, domain: str,
                            max_js: int = 20) -> dict:
    """Deep scan: pull archived JS files from the Wayback Machine and mine them
    for endpoints / API paths.

    Fetches raw archived copies via
    https://web.archive.org/web/{timestamp}id_/{original_url}
    (the `id_` modifier returns the original resource without rewriting).
    Off by default; enable with ASM_DEEP_SCAN=1.
    """
    result = {"js_files": 0, "endpoints": set()}
    if is_ip(domain):
        return result
    rows = await _cdx(client, domain, "timestamp,original",
                      extra="&filter=original:.*\\.js(\\?.*)?$&filter=statuscode:200",
                      limit=max_js * 3)
    seen_orig: set[str] = set()
    entries: list[tuple[str, str]] = []
    for row in rows:
        if not isinstance(row, list) or len(row) < 2:
            continue
        ts, original = row[0], row[1]
        if original in seen_orig:
            continue
        seen_orig.add(original)
        entries.append((ts, original))
        if len(entries) >= max_js:
            break

    sem = asyncio.Semaphore(6)

    async def _fetch(ts: str, original: str):
        arc = f"https://web.archive.org/web/{ts}id_/{original}"
        async with sem:
            try:
                r = await client.get(arc, timeout=HTTP_TIMEOUT)
            except httpx.HTTPError:
                return
        if r.status_code == 200 and r.text:
            result["js_files"] += 1
            result["endpoints"] |= _extract_endpoints_from_js(r.text[:400_000], domain)

    await asyncio.gather(*[_fetch(ts, o) for ts, o in entries])
    return result


async def breach_exposure(client: httpx.AsyncClient, domain: str) -> list[dict]:
    """Report *breach exposure* for a domain via Have I Been Pwned.

    The breach-catalogue query (which breaches affected this domain) is public
    and needs no key. The account-level count (/breacheddomain) needs
    ASM_HIBP_API_KEY and domain verification on HIBP. This reports breach
    membership metadata only and NEVER retrieves passwords or plaintext
    credentials.
    """
    if is_ip(domain):
        return []
    out: list[dict] = []
    # 1) keyless: breaches whose breached site is this domain
    try:
        r = await client.get(f"https://haveibeenpwned.com/api/v3/breaches?Domain={domain}",
                             headers={"user-agent": "ASM-Mapper"}, timeout=HTTP_TIMEOUT)
        if r.status_code == 200:
            for b in r.json():
                out.append({
                    "breach": b.get("Name"), "title": b.get("Title"),
                    "date": b.get("BreachDate"), "accounts": b.get("PwnCount"),
                    "data_classes": b.get("DataClasses", []), "source": "hibp-domain",
                })
    except (httpx.HTTPError, ValueError):
        pass
    # 2) keyed: exposed-account count across the domain
    key = _env("ASM_HIBP_API_KEY")
    if key:
        try:
            r2 = await client.get(
                f"https://haveibeenpwned.com/api/v3/breacheddomain/{domain}",
                headers={"hibp-api-key": key, "user-agent": "ASM-Mapper"},
                timeout=HTTP_TIMEOUT)
            if r2.status_code == 200:
                data = r2.json()
                total = sum(len(v) for v in data.values())
                if total:
                    out.append({"breach": "(domain accounts)",
                                "title": "Exposed accounts on domain",
                                "accounts": len(data), "exposures": total,
                                "data_classes": [], "source": "hibp-breacheddomain"})
        except (httpx.HTTPError, ValueError):
            pass

    # 3) DeHashed — leaked credentials for the domain (opt-in, paid API).
    #    Records METADATA ONLY: counts, source databases, and affected
    #    addresses (the client's own accounts, for remediation). It never
    #    stores plaintext passwords or hashes.
    dh_key = _env("ASM_DEHASHED_KEY")
    dh_email = _env("ASM_DEHASHED_EMAIL")
    if dh_key:
        try:
            r3 = await client.post(
                "https://api.dehashed.com/v2/search",
                headers={"Accept": "application/json", "Content-Type": "application/json",
                         "Dehashed-Api-Key": dh_key, "user-agent": "ASM-Mapper"},
                auth=(dh_email, dh_key) if dh_email else None,
                json={"query": f"domain:{domain}", "size": 100},
                timeout=HTTP_TIMEOUT)
            if r3.status_code == 200:
                data = r3.json()
                entries = data.get("entries") or []
                total = data.get("total", len(entries))
                if entries or total:
                    dbs: dict[str, int] = {}
                    with_creds = 0
                    emails: set[str] = set()
                    for e in entries:
                        db = e.get("database_name") or e.get("obtained_from") or "unknown"
                        dbs[db] = dbs.get(db, 0) + 1
                        if e.get("password") or e.get("hashed_password"):
                            with_creds += 1
                        if e.get("email"):
                            emails.add(str(e["email"]).lower())
                    out.append({
                        "breach": "(leaked credentials)",
                        "title": "Leaked credentials (DeHashed)",
                        "accounts": len(emails), "exposures": total,
                        "with_credentials": with_creds,
                        "databases": sorted(dbs, key=lambda k: -dbs[k])[:12],
                        "sample_accounts": sorted(emails)[:20],
                        "data_classes": ["Credentials"], "source": "dehashed",
                    })
        except (httpx.HTTPError, ValueError):
            pass
    return out


# --- port scanning ---------------------------------------------------------

async def shodan_internetdb(client: httpx.AsyncClient, ip: str) -> dict:
    """Passive ports / services / vulns for an IP from Shodan InternetDB.

    Free, keyless, and — crucially — this is Shodan's own scan data, so it
    reveals open ports WITHOUT us sending a single packet to the target. Returns
    {ports, cpes, vulns, hostnames, tags}. A 404 (no data for the IP) is normal.
    """
    empty = {"ports": [], "cpes": [], "vulns": [], "hostnames": [], "tags": []}
    try:
        r = await client.get(f"https://internetdb.shodan.io/{ip}", timeout=HTTP_TIMEOUT)
        if r.status_code != 200:
            return empty
        d = r.json()
        return {"ports": d.get("ports", []) or [], "cpes": d.get("cpes", []) or [],
                "vulns": d.get("vulns", []) or [], "hostnames": d.get("hostnames", []) or [],
                "tags": d.get("tags", []) or []}
    except (httpx.HTTPError, ValueError):
        return empty


def _cpe_to_tech(cpe: str) -> dict | None:
    """Parse a CPE string (cpe:/a:nginx:nginx:1.25.3) into a tech dict."""
    m = re.match(r"cpe:/?[aoh]:([^:]+):([^:]+)(?::([^:]+))?", cpe)
    if not m:
        return None
    vendor, product, version = m.group(1), m.group(2), m.group(3) or ""
    name = product.replace("_", " ").title() if product.islower() else product
    return {"name": name, "category": "software", "version": version,
            "evidence": ["shodan-cpe"], "confidence": 1, "verified": False}


async def _scan_one_port(ip: str, port: int, sem: asyncio.Semaphore,
                         delay: float = 0.0) -> dict | None:
    async with sem:
        if delay:
            import random
            await asyncio.sleep(delay + random.uniform(0, ACTIVE_JITTER))
        try:
            fut = asyncio.open_connection(ip, port)
            reader, writer = await asyncio.wait_for(fut, CONNECT_TIMEOUT)
        except (OSError, asyncio.TimeoutError):
            return None
        banner = ""
        try:
            data = await asyncio.wait_for(reader.read(160), 0.6)
            banner = data.decode("utf-8", "ignore").strip()
        except (OSError, asyncio.TimeoutError):
            pass
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except (OSError, asyncio.TimeoutError):
                pass
        return {"port": port, "banner": banner, "service": _guess_service(port, banner)}


def _guess_service(port: int, banner: str) -> str:
    for pat, name in BANNER_HINTS:
        m = re.search(pat, banner, re.I)
        if m:
            ver = m.group(1) if m.groups() else ""
            return f"{name} {ver}".strip()
    common = {
        21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http",
        110: "pop3", 143: "imap", 443: "https", 445: "smb", 3306: "mysql",
        3389: "rdp", 5432: "postgresql", 6379: "redis", 8080: "http-alt",
        9200: "elasticsearch", 27017: "mongodb", 11211: "memcached",
    }
    return common.get(port, "unknown")


async def scan_ports(ip: str, ports: list[int] | None = None,
                     concurrency: int | None = None, delay: float = 0.0) -> list[dict]:
    ports = ports if ports is not None else get_ports()
    sem = asyncio.Semaphore(concurrency or PORT_CONCURRENCY)
    tasks = [_scan_one_port(ip, p, sem, delay) for p in ports]
    results = await asyncio.gather(*tasks)
    return [r for r in results if r]


# --- verification: confirm each open port with a second, independent method --

def _nmap_available() -> bool:
    import shutil
    return shutil.which("nmap") is not None


def _nmap_open_ports(ip: str, ports: list[int]) -> set[int]:
    """Cross-check with nmap when it is installed. Returns the set it finds open."""
    import subprocess
    if not ports or not _nmap_available():
        return set()
    plist = ",".join(str(p) for p in ports)
    try:
        out = subprocess.run(
            ["nmap", "-Pn", "-p", plist, "-oG", "-", "--host-timeout", "30s", ip],
            capture_output=True, text=True, timeout=60,
        ).stdout
    except (subprocess.SubprocessError, OSError):
        return set()
    found = set()
    for m in re.finditer(r"(\d+)/open", out):
        found.add(int(m.group(1)))
    return found


async def _confirm_port(ip: str, port: int) -> str | None:
    """A second, independent confirmation using a layer appropriate to the port.

    - TLS ports: complete a TLS handshake  -> 'tls'
    - web ports: get an HTTP status line    -> 'http'
    - everything else: a fresh stdlib socket -> 'socket'
    Returns the method name if confirmed, else None.
    """
    if port in TLS_PORTS:
        def _tls():
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((ip, port), timeout=CONNECT_TIMEOUT) as s:
                with ctx.wrap_socket(s, server_hostname=ip):
                    return True
        try:
            await asyncio.to_thread(_tls)
            return "tls"
        except (OSError, ssl.SSLError):
            return None
    if port in WEB_PORTS:
        scheme = "http"
        try:
            async with httpx.AsyncClient(verify=False, timeout=CONNECT_TIMEOUT + 2) as c:
                r = await c.get(f"{scheme}://{ip}:{port}", follow_redirects=False)
            return "http" if r.status_code else None
        except httpx.HTTPError:
            return None
    # generic: independent stdlib socket connect (different impl than asyncio)
    def _sock():
        with socket.create_connection((ip, port), timeout=CONNECT_TIMEOUT):
            return True
    try:
        await asyncio.to_thread(_sock)
        return "socket"
    except OSError:
        return None


async def verify_ports(ip: str, open_ports: list[dict],
                       use_nmap: bool = True) -> list[dict]:
    """Annotate each port with the methods that independently confirmed it.

    method[0] is always the initial async connect ('tcp-connect'). We add a
    second-method confirmation and, if installed and enabled, nmap. verified ==
    True means at least two independent tools agree the port is open.
    """
    if not open_ports:
        return open_ports
    ports = [op["port"] for op in open_ports]
    nmap_open = await asyncio.to_thread(_nmap_open_ports, ip, ports) if use_nmap else set()
    confirmations = await asyncio.gather(*[_confirm_port(ip, p) for p in ports])
    for op, conf in zip(open_ports, confirmations):
        methods = ["tcp-connect"]
        if conf:
            methods.append(conf)
        if op["port"] in nmap_open:
            methods.append("nmap")
        op["methods"] = methods
        op["verified"] = len(methods) >= 2
    return open_ports


# --- web fingerprinting + endpoint discovery -------------------------------

class _LinkExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []
        self.scripts: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        d = dict(attrs)
        if tag == "a" and d.get("href"):
            self.links.append(d["href"])
        elif tag == "script" and d.get("src"):
            self.scripts.append(d["src"])


def _match_signatures(headers: dict, cookies: str, body: str) -> dict[str, dict]:
    """Return {name: {name, category, version, evidence:[...], confidence}}.

    Evidence lists every independent source that matched (header/cookie/body),
    so a technology confirmed by two or more sources is considered verified.
    """
    lower_headers = {k.lower(): v for k, v in headers.items()}
    found: dict[str, dict] = {}
    for name, category, source, pattern, vgroup in TECH_SIGNATURES:
        if source == "body":
            hay, tag = body, "body"
        elif source == "cookie":
            hay, tag = cookies, "cookie"
        elif source.startswith("header:"):
            hkey = source.split(":", 1)[1]
            hay, tag = lower_headers.get(hkey, ""), f"header:{hkey}"
        else:
            continue
        if not hay:
            continue
        m = re.search(pattern, hay, re.I)
        if not m:
            continue
        version = ""
        if vgroup and m.groups() and len(m.groups()) >= vgroup:
            version = (m.group(vgroup) or "").strip()
        entry = found.setdefault(name, {"name": name, "category": category,
                                        "version": "", "evidence": []})
        if version and not entry["version"]:
            entry["version"] = version
        if tag not in entry["evidence"]:
            entry["evidence"].append(tag)
    for e in found.values():
        e["confidence"] = len(e["evidence"])
        e["verified"] = e["confidence"] >= 2
    return found


# Product tokens commonly seen in Server / X-Powered-By, normalised for display.
PRODUCT_NAMES = {
    "apache": "Apache", "nginx": "nginx", "openssl": "OpenSSL", "php": "PHP",
    "microsoft-iis": "Microsoft-IIS", "iis": "Microsoft-IIS", "tomcat": "Tomcat",
    "jetty": "Jetty", "gunicorn": "Gunicorn", "werkzeug": "Werkzeug",
    "mod_wsgi": "mod_wsgi", "mod_ssl": "mod_ssl", "mod_perl": "mod_perl",
    "perl": "Perl", "python": "Python", "openresty": "OpenResty", "ruby": "Ruby",
    "passenger": "Phusion Passenger", "coyote": "Apache Coyote", "jbossweb": "JBoss Web",
    "express": "Express", "kestrel": "Kestrel", "litespeed": "LiteSpeed",
    "boa": "Boa", "lighttpd": "lighttpd", "cherrypy": "CherryPy", "unit": "NGINX Unit",
    "node": "Node.js", "phusion_passenger": "Phusion Passenger", "waitress": "Waitress",
}
PRODUCT_CATEGORY = {
    "Apache": "web-server", "nginx": "web-server", "Microsoft-IIS": "web-server",
    "OpenResty": "web-server", "lighttpd": "web-server", "LiteSpeed": "web-server",
    "OpenSSL": "crypto-lib", "PHP": "language", "Perl": "language", "Python": "language",
    "Ruby": "language", "Node.js": "runtime", "Tomcat": "app-server", "Jetty": "app-server",
    "Gunicorn": "app-server", "Werkzeug": "app-server", "Kestrel": "app-server",
    "Waitress": "app-server", "CherryPy": "app-server", "Phusion Passenger": "app-server",
    "Express": "framework",
}


def _bump(techs: dict, name: str, category: str, version: str, tag: str) -> None:
    e = techs.setdefault(name, {"name": name, "category": category,
                                "version": "", "evidence": []})
    if version and not e["version"]:
        e["version"] = version
    if not e.get("category"):
        e["category"] = category
    if tag not in e["evidence"]:
        e["evidence"].append(tag)
    e["confidence"] = len(e["evidence"])
    e["verified"] = e["confidence"] >= 2


def _merge_server_versions(headers: dict, techs: dict) -> None:
    """Extract every `product/version` pair from Server and X-Powered-By.

    Turns e.g. `Server: Apache/2.4.52 (Ubuntu) OpenSSL/1.1.1k mod_wsgi/4.9.4`
    into exact-versioned Apache, OpenSSL and mod_wsgi entries.
    """
    lh = {k.lower(): v for k, v in headers.items()}
    for hkey in ("server", "x-powered-by"):
        val = lh.get(hkey, "")
        if not val:
            continue
        for prod, ver in re.findall(r"([A-Za-z][\w\-\.]*?)/([0-9][\w.\-]*)", val):
            name = PRODUCT_NAMES.get(prod.lower(), prod)
            _bump(techs, name, PRODUCT_CATEGORY.get(name, "software"),
                  ver.strip(" .-"), f"header:{hkey}")


def _merge_generator(body: str, techs: dict) -> None:
    """Capture product + version from any <meta name="generator"> tag."""
    for content in re.findall(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)', body, re.I):
        content = content.strip()
        nm = re.match(r"([A-Za-z][A-Za-z0-9 .\-]*?)\s*(?=[\d(]|$)", content)
        name = (nm.group(1).strip() if nm and nm.group(1).strip() else content.split(" ")[0]).strip()
        vm = re.search(r"(\d+(?:\.\d+)+)", content)
        version = vm.group(1) if vm else ""
        if name and len(name) < 40:
            _bump(techs, name, "cms", version, "generator")


async def probe_web(client: httpx.AsyncClient, host: str, port: int,
                    depth: str = "full") -> dict:
    scheme = "https" if port in TLS_PORTS else "http"
    base = f"{scheme}://{host}:{port}" if port not in (80, 443) else f"{scheme}://{host}"
    result = {"base": base, "scheme": scheme, "techs": [], "endpoints": [], "tls": None}

    try:
        r = await client.get(base + "/")
    except (httpx.HTTPError, ssl.SSLError):
        return result

    headers = dict(r.headers)
    cookies = " ".join(r.headers.get_list("set-cookie")) if hasattr(r.headers, "get_list") else headers.get("set-cookie", "")
    body = r.text[:200_000]
    techs = _match_signatures(headers, cookies, body)   # {name: {...}}
    _merge_server_versions(headers, techs)              # exact product/version pairs
    _merge_generator(body, techs)                       # <meta generator> product+version
    result["techs"] = techs

    # homepage itself is an endpoint (actively confirmed)
    result["endpoints"].append({
        "url": str(r.url), "status": r.status_code, "type": "page", "verified": True,
        "content_type": headers.get("content-type", "").split(";")[0],
    })

    # same-host links from the homepage body (parsed, not fetched)
    parser = _LinkExtractor()
    try:
        parser.feed(body)
    except Exception:
        pass
    homepage_links = set()
    for href in parser.links:
        u = urljoin(base + "/", href)
        if urlparse(u).hostname == host and not _is_asset(u):
            homepage_links.add(_norm_endpoint(u))

    # PASSIVE: stop here — one GET total. Record homepage links as endpoints
    # (unverified) without sending a request to each.
    if depth == "passive":
        for u in list(homepage_links)[:MAX_CRAWL_LINKS]:
            result["endpoints"].append({"url": u, "status": None, "verified": False,
                "type": "api" if _looks_like_api(u, "") else "page", "source": "homepage-link"})
        return result

    # TLS certificate (light/full only)
    if scheme == "https":
        result["tls"] = _tls_info(host, port)

    # robots.txt + sitemap.xml for declared URLs
    seed_urls = await _seed_from_wellknown(client, base)
    seed_urls |= homepage_links

    # LIGHT probes only benign, expected paths; FULL adds the noisier recon set
    SAFE_PATHS = ["/robots.txt", "/sitemap.xml", "/.well-known/security.txt",
                  "/api", "/openapi.json", "/swagger.json", "/health", "/status",
                  "/metrics", "/graphql"]
    path_set = COMMON_PATHS if depth == "full" else SAFE_PATHS
    probe_targets = {base + p for p in path_set} | seed_urls
    probe_targets = list(probe_targets)[:MAX_CRAWL_LINKS + len(path_set)]

    # --- soft-404 / catch-all baseline -------------------------------------
    # Many SPAs and catch-all servers return 200 for ANY path. Learn the
    # "does-not-exist" response from unlikely paths, then discard probed
    # endpoints that merely echo it — the main source of endpoint false
    # positives on active scans.
    import random, hashlib
    soft404: list[tuple] = []
    for _ in range(2):
        rp = "/" + "".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789")
                           for _ in range(18)) + "/nope"
        try:
            b = await client.get(base + rp)
            soft404.append((b.status_code, len(b.text),
                            hashlib.md5(b.text[:6000].encode("utf-8", "ignore")).hexdigest()))
        except httpx.HTTPError:
            pass

    def _is_soft404(status: int, text: str) -> bool:
        for (s, ln, h) in soft404:
            if status != s:
                continue
            if abs(len(text) - ln) <= max(80, int(ln * 0.05)):
                return True
            if hashlib.md5(text[:6000].encode("utf-8", "ignore")).hexdigest() == h:
                return True
        return False

    seen_endpoints: dict[str, dict] = {}
    conc = ACTIVE_CONCURRENCY if depth == "light" else 20
    sem = asyncio.Semaphore(conc)

    async def _probe(u: str) -> None:
        async with sem:
            if depth == "light" and ACTIVE_DELAY:
                await asyncio.sleep(ACTIVE_DELAY + random.uniform(0, ACTIVE_JITTER))
            try:
                pr = await client.get(u)
            except httpx.HTTPError:
                return
        if pr.status_code >= 400 and pr.status_code not in (401, 403):
            return
        # catch-all servers answer 200 for everything — drop matches to baseline
        if pr.status_code in (200, 401, 403) and _is_soft404(pr.status_code, pr.text):
            return
        ctype = pr.headers.get("content-type", "").split(";")[0]
        etype = "api" if _looks_like_api(u, ctype) else "page"
        seen_endpoints[_norm_endpoint(str(pr.url))] = {
            "url": _norm_endpoint(str(pr.url)), "status": pr.status_code,
            "type": etype, "content_type": ctype, "verified": True,
        }

    await asyncio.gather(*[_probe(u) for u in probe_targets])
    result["endpoints"].extend(seen_endpoints.values())

    # path-based tech inference: a discovered endpoint is an independent source
    all_paths = " ".join(urlparse(e["url"]).path.lower() for e in result["endpoints"])
    for pat, name, category in PATH_TECH:
        if re.search(pat, all_paths, re.I):
            entry = techs.setdefault(name, {"name": name, "category": category,
                                            "version": "", "evidence": []})
            if "path" not in entry["evidence"]:
                entry["evidence"].append("path")
            entry["confidence"] = len(entry["evidence"])
            entry["verified"] = entry["confidence"] >= 2
    return result


def _looks_like_api(url: str, content_type: str) -> bool:
    path = urlparse(url).path.lower()
    if any(k in path for k in ("/api", "graphql", "swagger", "openapi", "/v1", "/v2", "api-docs")):
        return True
    return content_type in ("application/json", "application/graphql", "application/xml")


async def _seed_from_wellknown(client: httpx.AsyncClient, base: str) -> set[str]:
    urls: set[str] = set()
    for path in ("/robots.txt", "/sitemap.xml"):
        try:
            r = await client.get(base + path)
        except httpx.HTTPError:
            continue
        if r.status_code != 200:
            continue
        if path.endswith("robots.txt"):
            for line in r.text.splitlines():
                if line.lower().startswith(("allow:", "disallow:", "sitemap:")):
                    val = line.split(":", 1)[1].strip()
                    if val.startswith("http"):
                        urls.add(val)
                    elif val.startswith("/"):
                        urls.add(base + val)
        else:
            for loc in re.findall(r"<loc>(.*?)</loc>", r.text):
                urls.add(loc.strip())
    return set(list(urls)[:MAX_CRAWL_LINKS])


def _tls_info(host: str, port: int = 443) -> dict | None:
    """Fetch and parse the TLS certificate: issuer, expiry, SANs, weak-config
    flags. Uses the binary cert (getpeercert() is empty under CERT_NONE)."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((host, port), timeout=CONNECT_TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                der = ssock.getpeercert(binary_form=True)
                proto = ssock.version()
    except (OSError, ssl.SSLError, ValueError):
        return None
    if not der:
        return None
    try:
        from cryptography import x509
        from datetime import datetime, timezone

        cert = x509.load_der_x509_certificate(der)

        def _attr(name, oid):
            try:
                return name.get_attributes_for_oid(oid)[0].value
            except Exception:
                return ""
        cn = _attr(cert.subject, x509.NameOID.COMMON_NAME)
        issuer = (_attr(cert.issuer, x509.NameOID.ORGANIZATION_NAME)
                  or _attr(cert.issuer, x509.NameOID.COMMON_NAME))
        san: list[str] = []
        try:
            ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
            san = ext.value.get_values_for_type(x509.DNSName)
        except Exception:
            pass
        try:
            not_after = cert.not_valid_after_utc
            not_before = cert.not_valid_before_utc
        except AttributeError:
            not_after = cert.not_valid_after.replace(tzinfo=timezone.utc)
            not_before = cert.not_valid_before.replace(tzinfo=timezone.utc)
        days = (not_after - datetime.now(timezone.utc)).days
        sig = (cert.signature_hash_algorithm.name
               if cert.signature_hash_algorithm else "")
        self_signed = cert.subject.rfc4514_string() == cert.issuer.rfc4514_string()
        return {
            "host": host, "protocol": proto, "subject_cn": cn, "issuer": issuer,
            "not_after": not_after.strftime("%Y-%m-%d"),
            "not_before": not_before.strftime("%Y-%m-%d"),
            "days_to_expiry": days, "expired": days < 0,
            "expiring_soon": 0 <= days <= 21,
            "san": sorted(set(san))[:60], "sig_alg": sig,
            "self_signed": self_signed,
            "weak_protocol": proto in ("TLSv1", "TLSv1.1", "SSLv3", "SSLv2"),
            "weak_sig": sig.lower() in ("md5", "sha1"),
        }
    except Exception:
        return None


# --- top-level orchestration ----------------------------------------------

async def run_scan(target_value: str, enumerate_subs: bool = False,
                   deep: bool = True, mode: str | None = None) -> dict:
    """Run a scan of one target.

    mode: "passive" (default) sources ports/services/vulns from Shodan
    InternetDB and does at most a single homepage GET; "light" adds a small,
    throttled active layer; "aggressive" is the full active sweep.
    """
    mode = valid_mode(mode)
    active_ports = mode in ("light", "aggressive")
    active_waf = mode == "aggressive"
    sub_bruteforce = mode in ("light", "aggressive")
    web_depth = {"passive": "passive", "light": "light", "aggressive": "full"}[mode]

    findings: dict = {"hosts": [], "ports": [], "techs": {}, "endpoints": {},
                      "subdomains": [], "dns": {}, "nameservers": [], "waf": [],
                      "idp": [], "buckets": [], "breaches": [], "passive": {},
                      "dns_history": [], "vulns": [], "scan_mode": mode,
                      "lookalikes": [], "email": [], "certs": [], "takeover": [],
                      "impersonations": []}
    ips = resolve(target_value)
    findings["hosts"] = ips
    domain_target = not is_ip(target_value)

    limits = httpx.Limits(max_connections=40, max_keepalive_connections=20)
    async with httpx.AsyncClient(
        verify=False, follow_redirects=True, timeout=HTTP_TIMEOUT,
        limits=limits, headers={"User-Agent": "ASM-Mapper/1.0 (+asset-inventory)"},
    ) as client:
        # subdomain discovery runs even if the apex itself doesn't resolve/serve
        if enumerate_subs:
            findings["subdomains"] = await enumerate_subdomains(
                client, target_value, active=sub_bruteforce)

        # domain-level intelligence (DNS, name servers, WAF, identity, buckets)
        if domain_target and deep:
            recs = await asyncio.to_thread(dns_records, target_value)
            findings["dns"] = recs
            findings["nameservers"] = recs.get("NS", [])
            cnames = recs.get("CNAME", [])
            deep_enabled = _env("ASM_DEEP_SCAN") in ("1", "true", "yes")

            async def _noop():
                return None

            # Run every independent intel source concurrently. This is the main
            # latency win — previously each of these awaited in series, so one
            # slow source (e.g. look-alike validation) stalled the whole scan.
            (waf_r, idp_r, buckets_r, email_r, cert, takeover_r, lookalikes_r,
             vt, wb, breaches_r, deep_r, imperson_r) = await asyncio.gather(
                detect_waf(client, target_value, recs, active_probe=active_waf),
                detect_idp(client, target_value, recs),
                find_exposed_buckets(client, target_value),
                asyncio.to_thread(email_security, target_value) if enumerate_subs else _noop(),
                asyncio.to_thread(_tls_info, target_value, 443),
                check_takeover(client, target_value, cnames) if cnames else _noop(),
                find_lookalikes(client, target_value, ips, LOOKALIKE_MAX)
                    if (LOOKALIKE_ENABLED and enumerate_subs and not is_ip(target_value)) else _noop(),
                virustotal_domain(client, target_value),
                wayback_urls(client, target_value),
                breach_exposure(client, target_value),
                wayback_deep_scan(client, target_value) if deep_enabled else _noop(),
                find_brand_impersonations(client, target_value, BRAND_MAX)
                    if (BRAND_ENABLED and enumerate_subs and not is_ip(target_value)) else _noop(),
                return_exceptions=True,
            )

            def _ok(r, default):
                return default if (r is None or isinstance(r, Exception)) else r

            findings["waf"] = _ok(waf_r, [])
            findings["idp"] = _ok(idp_r, [])
            findings["buckets"] = _ok(buckets_r, [])
            findings["email"] = _ok(email_r, [])
            findings["breaches"] = _ok(breaches_r, [])
            findings["lookalikes"] = _ok(lookalikes_r, [])
            findings["impersonations"] = _ok(imperson_r, [])
            takeover_r = _ok(takeover_r, None)
            if takeover_r:
                findings["takeover"] = [takeover_r]
            vt = _ok(vt, {})
            wb = _ok(wb, [])
            cert = _ok(cert, None)

            # TLS certificate + SAN mining (needs cert result and the sub list)
            if cert:
                findings["certs"] = [cert]
                if enumerate_subs and cert.get("san"):
                    sfx = "." + target_value
                    san_subs = {s.lower().lstrip("*.") for s in cert["san"]
                                if s.lower().lstrip("*.").endswith(sfx)
                                and s.lower().lstrip("*.") != target_value
                                and not is_ip(s.lower().lstrip("*."))}
                    known = {s["host"] for s in findings["subdomains"]}
                    extra = await _verify_resolves(san_subs - known, 50)
                    for e in extra:
                        e["via"] = "tls-san"
                    findings["subdomains"].extend(extra)

            deep = {"js_files": 0, "endpoints": set()}
            if deep_enabled:
                deep = _ok(deep_r, deep)
            findings["passive"] = {"virustotal": vt, "wayback_count": len(wb),
                                   "deep_js_files": deep["js_files"]}

            # DNS history: the scanner's own observed resolutions (keyless — the
            # asset's first_seen/last_seen build a real timeline as IPs change)
            # merged with VirusTotal passive DNS (deep historical, needs key).
            hist: dict[str, dict] = {}
            for ip in ips:
                hist[ip] = {"ip": ip, "resolver": "scanner", "source": "observed"}
            for r in vt.get("resolutions", []):
                if r.get("ip"):
                    hist[r["ip"]] = {**hist.get(r["ip"], {}), **r, "source": "virustotal"}
            findings["dns_history"] = list(hist.values())

            # fold passively-found subdomains (VT) into the verified subdomain set
            if enumerate_subs and vt.get("subdomains"):
                known = {s["host"] for s in findings["subdomains"]}
                extra = await _verify_resolves(
                    {s for s in vt["subdomains"] if s not in known}, 100)
                for e in extra:
                    e["via"] = "virustotal"
                findings["subdomains"].extend(extra)

            # fold historical URLs (Wayback), VT URLs/references, and deep-scan
            # endpoints into the endpoint set. These are PASSIVE (unverified) —
            # they may be stale/dead, so mark them so and filter static assets.
            def _add_passive_endpoint(u: str, source: str, status=None):
                if not u or _is_asset(u):
                    return
                key = _norm_endpoint(u)
                if key in findings["endpoints"]:
                    return
                findings["endpoints"][key] = {
                    "url": key, "status": status,
                    "type": "api" if _looks_like_api(key, "") else "page",
                    "source": source, "verified": False}

            for u in wb[:120]:
                _add_passive_endpoint(u, "wayback")
            for item in vt.get("urls", [])[:80]:
                _add_passive_endpoint(item["url"], "virustotal", item.get("status"))
            for ref in vt.get("references", [])[:30]:
                _add_passive_endpoint(ref["url"], "vt-reference")
            for u in list(deep["endpoints"])[:200]:
                full = u if u.startswith("http") else f"https://{target_value}{u}"
                _add_passive_endpoint(full, "js-deepscan")

        if not ips:
            return findings

        def _merge_tech(key: str, t: dict) -> None:
            cur = findings["techs"].get(key)
            if not cur:
                findings["techs"][key] = t
            else:
                cur["evidence"] = sorted(set(cur.get("evidence", []) + t.get("evidence", [])))
                cur["confidence"] = len(cur["evidence"])
                cur["verified"] = cur["confidence"] >= 2
                if t.get("version") and not cur.get("version"):
                    cur["version"] = t["version"]

        for ip in ips:
            # PASSIVE port/service/vuln data from Shodan InternetDB (no packets
            # sent to the target). Available in every mode.
            idb = await shodan_internetdb(client, ip)
            for p in idb["ports"]:
                findings["ports"].append({
                    "ip": ip, "port": p, "service": _guess_service(p, ""),
                    "banner": "", "methods": ["shodan-passive"], "verified": True,
                    "source": "shodan"})
            for cve in idb["vulns"]:
                findings["vulns"].append({"ip": ip, "cve": cve, "source": "shodan"})
            for cpe in idb["cpes"]:
                t = _cpe_to_tech(cpe)
                if t:
                    _merge_tech(t["name"], t)

            # ACTIVE port scan only in light/aggressive, throttled
            active_open = []
            if active_ports:
                plist = LIGHT_PORTS if mode == "light" else get_ports()
                conc = ACTIVE_CONCURRENCY if mode == "light" else PORT_CONCURRENCY
                delay = ACTIVE_DELAY if mode == "light" else 0.0
                scanned = await scan_ports(ip, plist, conc, delay)
                scanned = await verify_ports(ip, scanned, use_nmap=(mode == "aggressive"))
                known = {p["port"] for p in findings["ports"]}
                for op in scanned:
                    op["ip"] = ip
                    if op["port"] in known:
                        continue
                    findings["ports"].append(op)
                    active_open.append(op["port"])

            # decide which web ports to fingerprint
            host_for_web = target_value if not target_value.replace(".", "").isdigit() else ip
            passive_web_ports = {p["port"] for p in findings["ports"] if p["port"] in WEB_PORTS}
            if mode == "passive":
                # one homepage GET on the best available web port only
                web_ports = [443] if 443 in passive_web_ports or not passive_web_ports else \
                            [next(iter(passive_web_ports))]
                web_ports = web_ports[:1]
            else:
                web_ports = sorted(passive_web_ports | set(p for p in active_open if p in WEB_PORTS))

            for port in web_ports:
                web = await probe_web(client, host_for_web, port, depth=web_depth)
                for key, t in web["techs"].items():
                    t["port"] = port
                    _merge_tech(key, t)
                for ep in web["endpoints"]:
                    findings["endpoints"].setdefault(ep["url"], ep)
                if web.get("tls"):
                    findings.setdefault("tls", {})[f"{host_for_web}:{port}"] = web["tls"]
            # in passive mode we only fingerprint the apex once, not every IP
            if mode == "passive":
                break

    findings["techs"] = list(findings["techs"].values())
    findings["endpoints"] = list(findings["endpoints"].values())
    return findings
